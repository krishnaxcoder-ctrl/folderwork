<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio Testimonials Widget.
 *
 * @since 1.0
 */

class Minterio_Testimonials_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-testimonials';
	}

	public function get_title() {
		return esc_html__( 'Testimonials', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'heading_tab',
			[
				'label' => esc_html__( 'Heading', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_tab',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image', [
				'label' => esc_html__( 'Image', 'minterio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'name', [
				'label'       => esc_html__( 'Name', 'minterio-plugin' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter name', 'minterio-plugin' ),
				'default' => esc_html__( 'Name', 'minterio-plugin' ),
			]
		);

		$repeater->add_control(
			'company', [
				'label'       => esc_html__( 'Company', 'minterio-plugin' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter company', 'minterio-plugin' ),
				'default' => esc_html__( 'Company', 'minterio-plugin' ),
			]
		);

		$repeater->add_control(
			'text', [
				'label'       => esc_html__( 'Text', 'minterio-plugin' ),
				'type'        => Controls_Manager::WYSIWYG,
				'placeholder' => esc_html__( 'Enter text', 'minterio-plugin' ),
				'default' => esc_html__( 'Text', 'minterio-plugin' ),
			]
		);

		$repeater->add_control(
			'rating', [
				'label'       => esc_html__( 'Rating', 'arter-plugin' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => esc_html__( 'Enter rating', 'arter-plugin' ),
				'default'	=> 5,
				'min' => 0,
				'max' => 5,
				'step' => 1,
			]
		);

		$this->add_control(
			'items',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ name }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'heading_styling',
			[
				'label' => esc_html__( 'Heading', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .section-title .sub-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Title Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .section-title .sub-title',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_styling',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'item_name_color',
			[
				'label' => esc_html__( 'Name Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .user-info > h3' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_name_typography',
				'label' => esc_html__( 'Name Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .user-info > h3',
			]
		);

		$this->add_control(
			'item_company_color',
			[
				'label' => esc_html__( 'Company Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .user-info > span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_company_typography',
				'label' => esc_html__( 'Company Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .user-info > span',
			]
		);

		$this->add_control(
			'item_text_color',
			[
				'label' => esc_html__( 'Text Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .testi-slide > .description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_text_typography',
				'label' => esc_html__( 'Text Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .testi-slide > .description',
			]
		);

		$this->add_control(
			'item_rating_color',
			[
				'label' => esc_html__( 'Rating Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .testi-slide .rating li' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'title', 'basic' );

		?>

		<section class="block testi-section">
			<div class="container">
				<?php if ( $settings['title'] ) : ?>
				<div class="section-title">
					<h3 class="sub-title">
						<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
							<?php echo wp_kses_post( $settings['title'] ); ?>
						</span>
					</h3>
				</div><!--section-title end-->
				<?php endif; ?>
				<?php if ( $settings['items'] ) : ?>
				<div class="testimonial-section">
					<div class="row testi-carousel">
						<?php foreach ( $settings['items'] as $index => $item ) :
							$item_name = $this->get_repeater_setting_key( 'name', 'items', $index );
					    	$this->add_inline_editing_attributes( $item_name, 'basic' );

					    	$item_company = $this->get_repeater_setting_key( 'company', 'items', $index );
					    	$this->add_inline_editing_attributes( $item_company, 'basic' );

					    	$item_text = $this->get_repeater_setting_key( 'text', 'items', $index );
					    	$this->add_inline_editing_attributes( $item_text, 'basic' );
						?>
						<div class="col-lg-4">
							<div class="testi-slide">
								<div class="testi-head">
									<?php if ( $item['image'] ) : $image = wp_get_attachment_image_url( $item['image']['id'], 'minterio_900x900' ); ?>
									<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>" />
									<?php endif; ?>
									<?php if ( $item['name'] || $item['company'] ) : ?>
									<div class="user-info">
										<?php if ( $item['name'] ) : ?>
										<h3>
											<span <?php echo $this->get_render_attribute_string( $item_name ); ?>>
												<?php echo wp_kses_post( $item['name'] ); ?>
											</span>
										</h3>
										<?php endif; ?>
										<?php if ( $item['company'] ) : ?>
										<span>
											<span <?php echo $this->get_render_attribute_string( $item_company ); ?>>
												<?php echo wp_kses_post( $item['company'] ); ?>
											</span>
										</span>
										<?php endif; ?>
									</div>
									<?php endif; ?>
								</div>
								<?php if ( $item['text'] ) : ?>
								<div class="description">
									<div <?php echo $this->get_render_attribute_string( $item_text ); ?>>
										<?php echo wp_kses_post( $item['text'] ); ?>
									</div>
								</div>
								<?php endif; ?>
								<?php if ( $item['rating'] ) : ?>
								<ul class="rating">
									<?php for ( $i = 1; $i <= 5; $i++ ) : ?>
					                <?php if ( $item['rating'] >= $i ) : ?>
					                <li><i class="la la-star"></i></li>
					                <?php else : ?>
					                <li class="empty"><i class="la la-star"></i></li>
					              	<?php endif; ?>
					                <?php endfor; ?>
								</ul>
								<?php endif; ?>
							</div><!--testi-slide end-->
						</div>
						<?php endforeach; ?>
					</div>
				</div><!--testimonial-section end-->
				<?php endif; ?>
			</div>
		</section>

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() { ?>

		<#
		view.addInlineEditingAttributes( 'title', 'basic' );
		#>

		<section class="block testi-section">
			<div class="container">
				<# if ( settings.title ) { #>
				<div class="section-title">
					<h3 class="sub-title">
						<span {{{ view.getRenderAttributeString( 'title' ) }}}>
	        				{{{ settings.title }}}
	        			</span>
					</h3>
				</div><!--section-title end-->
				<# } #>
				<# if ( settings.items ) { #>
				<div class="testimonial-section">
					<div class="row testi-carousel">
						<# _.each( settings.items, function( item, index ) {
						    var item_name = view.getRepeaterSettingKey( 'name', 'items', index );
						    view.addInlineEditingAttributes( item_name, 'basic' );

						    var item_company = view.getRepeaterSettingKey( 'company', 'items', index );
						    view.addInlineEditingAttributes( item_company, 'basic' );

						    var item_text = view.getRepeaterSettingKey( 'text', 'items', index );
						    view.addInlineEditingAttributes( item_text, 'advanced' );
						#>
						<div class="col-lg-4">
							<div class="testi-slide">
								<div class="testi-head">
									<# if ( item.image ) { #>
									<img src="{{{ item.image.url }}}" alt="{{{ item.name }}}" />
									<# } #>
									<# if ( item.name || item.company ) { #>
									<div class="user-info">
										<# if ( item.name ) { #>
										<h3>
											<span {{{ view.getRenderAttributeString( item_name ) }}}>
												{{{ item.name }}}
											</span>
										</h3>
										<# } #>
										<# if ( item.company ) { #>
										<span>
											<span {{{ view.getRenderAttributeString( item_company ) }}}>
												{{{ item.company }}}
											</span>
										</span>
										<# } #>
									</div>
									<# } #>
								</div>
								<# if ( item.text ) { #>
								<div class="description">
									<div {{{ view.getRenderAttributeString( item_text ) }}}>
										{{{ item.text }}}
									</div>
								</div>
								<# } #>
								<# if ( item.rating ) { #>
								<ul class="rating">
									<# for ( var i = 1; i <= 5; i++ ) { #>
					                <# if ( item.rating >= i ) { #>
					                <li><i class="la la-star"></i></li>
					                <# } else { #>
					                <li class="empty"><i class="la la-star"></i></li>
					              	<# } #>
					                <# } #>
								</ul>
								<# } #>
							</div><!--testi-slide end-->
						</div>
						<# }); #>
					</div>
				</div><!--testimonial-section end-->
				<# } #>
			</div>
		</section>

	<?php }
}

Plugin::instance()->widgets_manager->register( new Minterio_Testimonials_Widget() );
