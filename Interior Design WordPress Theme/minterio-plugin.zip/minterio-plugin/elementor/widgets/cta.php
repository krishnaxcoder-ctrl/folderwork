<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio CTA Widget.
 *
 * @since 1.0
 */

class Minterio_CTA_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-call-to-action';
	}

	public function get_title() {
		return esc_html__( 'Call to Action', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'content_tab',
			[
				'label' => esc_html__( 'Content', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
			]
		);

		$this->add_control(
			'image',
			[
				'label'       => esc_html__( 'Image', 'minterio-plugin' ),
				'type'        => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'bgimages', [
				'label' => esc_html__( 'Background Image', 'minterio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri() . '/assets/images/main-banner-bg.jpg',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'action_tab',
			[
				'label' => esc_html__( 'Action', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'type',
			[
				'label'       => esc_html__( 'Type', 'minterio-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'form',
				'options' => [
					'form'  => __( 'Form', 'minterio-plugin' ),
					'button' => __( 'Button', 'minterio-plugin' ),
				],
			]
		);

		$this->add_control(
			'button',
			[
				'label'       => esc_html__( 'Button', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter Button Label', 'minterio-plugin' ),
				'default'     => esc_html__( 'Button', 'minterio-plugin' ),
				'condition' => [
		            'type' => 'button',
		        ],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'link',
			[
				'label' => esc_html__( 'URL', 'minterio-plugin' ),
				'label_block' => true,
				'type' => Controls_Manager::URL,
				'show_external' => true,
				'condition' => [
		            'type' => 'button',
		        ],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'contact_form',
			[
				'label' => esc_html__( 'Select CF7 Form', 'minterio-plugin' ),
				'type' => Controls_Manager::SELECT,
				'default' => 1,
				'options' => $this->contact_form_list(),
				'condition' => [
		            'type' => 'form'
		        ],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'settings_tab',
			[
				'label' => esc_html__( 'Settings', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'layout',
			[
				'label'       => esc_html__( 'Layout', 'minterio-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'style-1',
				'options' => [
					'style-1'  => __( 'Style 1', 'minterio-plugin' ),
					'style-2' => __( 'Style 2', 'minterio-plugin' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_styling',
			[
				'label' => esc_html__( 'Content Styling', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .consult-text .sub-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Title Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .consult-text .sub-title',
			]
		);

		$this->add_control(
			'button_color',
			[
				'label' => esc_html__( 'Button Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .consult-text .lnk-default' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_typography',
				'label' => esc_html__( 'Button Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .consult-text .lnk-default',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render Contact Form List.
	 *
	 * @since 1.0
	 */
	protected function contact_form_list() {
		$cf7_posts = get_posts( 'post_type="wpcf7_contact_form"&numberposts=-1' );

		$cf7_forms = array();

		if ( $cf7_posts ) {
			foreach ( $cf7_posts as $cf7_form ) {
				$cf7_forms[ $cf7_form->ID ] = $cf7_form->post_title;
			}
		} else {
			$cf7_forms[ esc_html__( 'No contact forms found', 'minterio-plugin' ) ] = 0;
		}

		return $cf7_forms;
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'title', 'basic' );
		$this->add_inline_editing_attributes( 'button', 'basic' );

		?>

		<?php if ( $settings['layout'] == 'style-1' ) : ?>
		<section class="consultation-sec">
			<div class="consultation-sec-bg" <?php if ( $settings['bgimages'] ) : ?>style="background-image: url(<?php echo esc_url( $settings['bgimages']['url'] ); ?>);"<?php endif; ?>></div>
			<div class="container">
				<div class="consultation-section">
					<div class="row align-items-center">
						<div class="col-lg-7">
							<div class="consult-text">
								<?php if ( $settings['title'] ) : ?>
								<h3 class="sub-title">
									<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
										<?php echo wp_kses_post( $settings['title'] ); ?>
									</span>
								</h3>
								<?php endif; ?>
								<?php if ( $settings['button'] || $settings['contact_form'] ) : ?>
								<?php if ( $settings['type'] == 'button' ) : ?>
								<?php if ( $settings['button'] ) : ?>
								<!-- button -->
								<a<?php if ( $settings['link'] ) : ?><?php if ( $settings['link']['is_external'] ) : ?> target="_blank"<?php endif; ?><?php if ( $settings['link']['nofollow'] ) : ?> rel="nofollow"<?php endif; ?> href="<?php echo esc_url( $settings['link']['url'] ); ?>"<?php endif; ?> class="lnk-default button-only">
									<span <?php echo $this->get_render_attribute_string( 'button' ); ?>>
										<?php echo esc_html( $settings['button'] ); ?>
									</span>
									<i class="la la-arrow-right"></i>
									<span class="hover"></span>
								</a>
								<?php endif; ?>
								<?php else : ?>

								<?php if ( $settings['contact_form'] ) : ?>
								<!-- newslatter form -->
								<div class="subsc-form">
									<?php echo do_shortcode( '[contact-form-7 id="'. esc_attr( $settings['contact_form'] ) .'"]' ); ?>
								</div>
								<?php endif; ?>
								<?php endif; ?>
								<?php endif; ?>
							</div><!--consult-text end-->
						</div>
						<div class="col-lg-5">
							<div class="consult-img wow slideInUp" data-wow-duration="1000ms">
								<?php if ( $settings['image'] ) : $image = wp_get_attachment_image_url( $settings['image']['id'], 'minterio_900xAuto' ); ?>
								<img src="<?php echo esc_url( $image ); ?>" alt="" />
								<?php endif; ?>
							</div><!--consult-img end-->
						</div>
					</div>
				</div><!--consultation-section end-->
			</div>
		</section>
		<?php endif; ?>

		<?php if ( $settings['layout'] == 'style-2' ) : ?>
		<section class="block">
			<div class="container">
				<div class="consult-text style2 mt-0">
					<?php if ( $settings['title'] ) : ?>
					<h3 class="sub-title">
						<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
							<?php echo wp_kses_post( $settings['title'] ); ?>
						</span>
					</h3>
					<?php endif; ?>
					<?php if ( $settings['button'] || $settings['contact_form'] ) : ?>
					<?php if ( $settings['type'] == 'button' ) : ?>
					<?php if ( $settings['button'] ) : ?>
					<!-- button -->
					<a<?php if ( $settings['link'] ) : ?><?php if ( $settings['link']['is_external'] ) : ?> target="_blank"<?php endif; ?><?php if ( $settings['link']['nofollow'] ) : ?> rel="nofollow"<?php endif; ?> href="<?php echo esc_url( $settings['link']['url'] ); ?>"<?php endif; ?> class="lnk-default button-only">
						<span <?php echo $this->get_render_attribute_string( 'button' ); ?>>
							<?php echo esc_html( $settings['button'] ); ?>
						</span>
						<i class="la la-arrow-right"></i>
						<span class="hover"></span>
					</a>
					<?php endif; ?>
					<?php else : ?>

					<?php if ( $settings['contact_form'] ) : ?>
					<div class="subsc-form">
						<?php echo do_shortcode( '[contact-form-7 id="'. esc_attr( $settings['contact_form'] ) .'"]' ); ?>
					</div>
					<?php endif; ?>
					<?php endif; ?>
					<?php endif; ?>
				</div><!--consult-text end-->
				<?php if ( $settings['image'] ) : $image = wp_get_attachment_image_url( $settings['image']['id'], 'minterio_1920xAuto' ); ?>
				<div class="cnst-img">
					<img src="<?php echo esc_url( $image ); ?>" alt="" />
				</div><!--cnst-img end-->
				<?php endif; ?>
			</div>
		</section>
		<?php endif; ?>

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() { ?>

		<#
		view.addInlineEditingAttributes( 'title', 'basic' );
		view.addInlineEditingAttributes( 'button', 'basic' );
		#>

		<# if ( settings.layout == 'style-1' ) { #>
		<section class="consultation-sec">
			<div class="consultation-sec-bg" <# if ( settings.bgimages ) { #>style="background-image: url({{{ settings.bgimages.url }}}"<# } #>></div>
			<div class="container">
				<div class="consultation-section">
					<div class="row align-items-center">
						<div class="col-lg-7">
							<div class="consult-text">
								<# if( settings.title ) { #>
								<h3 class="sub-title">
									<span {{{ view.getRenderAttributeString( 'title' ) }}}>{{{ settings.title }}}</span>
								</h3>
								<# } #>
								<# if ( settings.button || settings.contact_form ) { #>
								<# if ( settings.type == 'button' ) { #>
								<# if ( settings.button ) { #>
								<!-- button -->
								<a<# if ( settings.link ) { #><# if ( settings.link.is_external ) { #> target="_blank"<# } #><# if ( settings.link.nofollow ) { #> rel="nofollow"<# } #> href="{{{ settings.link.url }}}"<# } #> class="lnk-default button-only">
									<span {{{ view.getRenderAttributeString( 'button' ) }}}>{{{ settings.button }}}</span>
									<i class="la la-arrow-right"></i>
									<span class="hover"></span>
								</a>
								<# } #>
								<# } else { #>

								<# if ( settings.contact_form ) { #>
								<!-- newslatter form -->
								<div class="subsc-form">
									[contact-form-7 id="{{{ settings.contact_form }}}"]
								</div>
								<# } #>
								<# } #>
								<# } #>
							</div><!--consult-text end-->
						</div>
						<div class="col-lg-5">
							<div class="consult-img wow slideInUp" data-wow-duration="1000ms">
								<# if( settings.image ) { #>
								<img src="{{{ settings.image.url }}}" alt="" />
								<# } #>
							</div><!--consult-img end-->
						</div>
					</div>
				</div><!--consultation-section end-->
			</div>
		</section>
		<# } #>

		<# if ( settings.layout == 'style-2' ) { #>
		<section class="block">
			<div class="container">
				<div class="consult-text style2 mt-0">
					<# if( settings.title ) { #>
					<h3 class="sub-title">
						<span {{{ view.getRenderAttributeString( 'title' ) }}}>{{{ settings.title }}}</span>
					</h3>
					<# } #>
					<# if ( settings.button || settings.contact_form ) { #>
					<# if ( settings.type == 'button' ) { #>
					<# if ( settings.button ) { #>
					<!-- button -->
					<a<# if ( settings.link ) { #><# if ( settings.link.is_external ) { #> target="_blank"<# } #><# if ( settings.link.nofollow ) { #> rel="nofollow"<# } #> href="{{{ settings.link.url }}}"<# } #> class="lnk-default button-only">
						<span {{{ view.getRenderAttributeString( 'button' ) }}}>{{{ settings.button }}}</span>
						<i class="la la-arrow-right"></i>
						<span class="hover"></span>
					</a>
					<# } #>
					<# } else { #>

					<# if ( settings.contact_form ) { #>
					<div class="subsc-form">
						[contact-form-7 id="{{{ settings.contact_form }}}"]
					</div>
					<# } #>
					<# } #>
					<# } #>
				</div><!--consult-text end-->
				<# if( settings.image ) { #>
				<div class="cnst-img">
					<img src="{{{ settings.image.url }}}" alt="" />
				</div><!--cnst-img end-->
				<# } #>
			</div>
		</section>
		<# } #>

	<?php }
}

Plugin::instance()->widgets_manager->register( new Minterio_CTA_Widget() );
