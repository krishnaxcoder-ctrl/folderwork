<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio Services List Widget.
 *
 * @since 1.0
 */

class Minterio_Services_List_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-services-list';
	}

	public function get_title() {
		return esc_html__( 'Services (List)', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'heading_tab',
			[
				'label' => esc_html__( 'Heading', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter description', 'minterio-plugin' ),
				'default'     => esc_html__( 'Description', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_tab',
			[
				'label' => esc_html__( 'Content', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image', [
				'label' => esc_html__( 'Image', 'minterio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'title', [
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'text', [
				'label'       => esc_html__( 'Text', 'minterio-plugin' ),
				'type'        => Controls_Manager::WYSIWYG,
				'placeholder' => esc_html__( 'Enter text', 'minterio-plugin' ),
				'default' => esc_html__( 'Enter text', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'more_text', [
				'label' => esc_html__( 'Button (Text)', 'minterio-plugin' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Button Text', 'minterio-plugin' ),
				'default' => '',
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'more_link', [
				'label' => esc_html__( 'Button (URL)', 'minterio-plugin' ),
				'label_block' => true,
				'type' => Controls_Manager::URL,
				'show_external' => true,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'items',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'heading_styling',
			[
				'label' => esc_html__( 'Heading', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .section-title .sub-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Title Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .section-title .sub-title',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label' => esc_html__( 'Description Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .section-title.style2 p' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'label' => esc_html__( 'Description Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .section-title.style2 p',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_styling',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'item_title_color',
			[
				'label' => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .svss-info > h3' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_title_typography',
				'label' => esc_html__( 'Title Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .svss-info > h3',
			]
		);

		$this->add_control(
			'item_text_color',
			[
				'label' => esc_html__( 'Text Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .svss-info .description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_text_typography',
				'label' => esc_html__( 'Text Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .svss-info .description',
			]
		);

		$this->add_control(
			'item_btn_color',
			[
				'label' => esc_html__( 'Button Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .svss-info .lnk-default2' => 'color: {{VALUE}};',
					'{{WRAPPER}} .svss-info .lnk-default2:before' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_btn_typography',
				'label' => esc_html__( 'Button Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .svss-info .lnk-default2',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'title', 'basic' );
		$this->add_inline_editing_attributes( 'description', 'advanced' );

		?>

		<section class="block">
			<div class="container">
				<?php if ( $settings['title'] || $settings['description'] ) : ?>
				<div class="section-title style2 align-items-center">
					<?php if ( $settings['title'] ) : ?>
					<h3 class="sub-title mw-45">
						<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
							<?php echo wp_kses_post( $settings['title'] ); ?>
						</span>
					</h3>
					<?php endif; ?>
					<?php if ( $settings['description'] ) : ?>
					<p class="mw-45">
						<span <?php echo $this->get_render_attribute_string( 'description' ); ?>>
							<?php echo wp_kses_post( $settings['description'] ); ?>
						</span>
					</p>
					<?php endif; ?>
					<div class="clearfix"></div>
				</div>
				<?php endif; ?>
				<?php if ( $settings['items'] ) : ?>
				<div class="svs-section">
					<?php foreach ( $settings['items'] as $index => $item ) :
				    	$item_title = $this->get_repeater_setting_key( 'title', 'items', $index );
				    	$this->add_inline_editing_attributes( $item_title, 'basic' );

				    	$item_text = $this->get_repeater_setting_key( 'text', 'items', $index );
				    	$this->add_inline_editing_attributes( $item_text, 'advanced' );

				    	$item_more_text = $this->get_repeater_setting_key( 'more_text', 'items', $index );
				    	$this->add_inline_editing_attributes( $item_more_text, 'basic' );
					?>
					<div class="svs-item">
						<?php if ( $item['image'] ) : $image = wp_get_attachment_image_url( $item['image']['id'], 'minterio_900x900' ); ?>
						<div class="svs-img">
							<img src="<?php echo esc_url( $image ); ?>" alt="" class="w-100" />
						</div>
						<?php endif; ?>
						<div class="svss-info">
							<?php if ( $item['title'] ) : ?>
							<h3>
								<span <?php echo $this->get_render_attribute_string( $item_title ); ?>>
									<?php echo wp_kses_post( $item['title'] ); ?>
								</span>
							</h3>
							<?php endif; ?>
							<?php if ( $item['text'] ) : ?>
							<div class="description">
								<div <?php echo $this->get_render_attribute_string( $item_text ); ?>>
									<?php echo wp_kses_post( $item['text'] ); ?>
								</div>
							</div>
							<?php endif; ?>
							<?php if ( $item['more_text'] ) : ?>
							<a<?php if ( $item['more_link'] ) : ?><?php if ( $item['more_link']['is_external'] ) : ?> target="_blank"<?php endif; ?><?php if ( $item['more_link']['nofollow'] ) : ?> rel="nofollow"<?php endif; ?> href="<?php echo esc_url( $item['more_link']['url'] ); ?>"<?php endif; ?> class="lnk-default2">
								<span <?php echo $this->get_render_attribute_string( $item_more_text ); ?>>
									<?php echo wp_kses_post( $item['more_text'] ); ?>
								</span>
								<i class="la la-arrow-right"></i>
							</a>
							<?php endif; ?>
						</div>
					</div><!--svs-item end-->
					<?php endforeach; ?>
				</div><!--svs-section end-->
				<?php endif; ?>
			</div>
		</section>

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() { ?>
		<#
		view.addInlineEditingAttributes( 'title', 'basic' );
		view.addInlineEditingAttributes( 'description', 'advanced' );
		#>

		<section class="block">
			<div class="container">
				<# if ( settings.title || settings.description ) { #>
				<div class="section-title style2 align-items-center">
					<# if ( settings.title ) { #>
					<h3 class="sub-title mw-45">
						<span {{{ view.getRenderAttributeString( 'title' ) }}}>
	        				{{{ settings.title }}}
	        			</span>
					</h3>
					<# } #>
					<# if ( settings.description ) { #>
					<p class="mw-45">
						<span {{{ view.getRenderAttributeString( 'description' ) }}}>
	        				{{{ settings.description }}}
	        			</span>
					</p>
					<# } #>
					<div class="clearfix"></div>
				</div>
				<# } #>
				<# if ( settings.items ) { #>
				<div class="svs-section">
					<# _.each( settings.items, function( item, index ) {
						var item_title = view.getRepeaterSettingKey( 'title', 'items', index );
					    view.addInlineEditingAttributes( item_title, 'basic' );

					    var item_text = view.getRepeaterSettingKey( 'text', 'items', index );
					    view.addInlineEditingAttributes( item_text, 'advanced' );

					    var item_more_text = view.getRepeaterSettingKey( 'more_text', 'items', index );
					    view.addInlineEditingAttributes( item_more_text, 'basic' );
					#>
					<div class="svs-item">
						<# if ( item.image ) { #>
						<div class="svs-img">
							<img src="{{{ item.image.url }}}" alt="" class="w-100" />
						</div>
						<# } #>
						<div class="svss-info">
							<# if ( item.title ) { #>
							<h3>
								<span {{{ view.getRenderAttributeString( item_title ) }}}>
									{{{ item.title }}}
								</span>
							</h3>
							<# } #>
							<# if ( item.text ) { #>
							<div class="description">
								<div {{{ view.getRenderAttributeString( item_text ) }}}>
									{{{ item.text }}}
								</div>
							</div>
							<# } #>
							<# if ( item.more_text ) { #>
							<a<# if ( item.more_link ) { #><# if ( item.more_link.is_external ) { #> target="_blank"<# } #><# if ( item.more_link.nofollow ) { #> rel="nofollow"<# } #> href="{{{ item.more_link.url }}}"<# } #> class="lnk-default2">
								<span {{{ view.getRenderAttributeString( item_more_text ) }}}>{{{ item.more_text }}}</span>
								<i class="la la-arrow-right"></i>
							</a>
							<# } #>
						</div>
					</div><!--svs-item end-->
					<# }); #>
				</div><!--svs-section end-->
				<# } #>
			</div>
		</section>

	<?php }
}

Plugin::instance()->widgets_manager->register( new Minterio_Services_List_Widget() );
