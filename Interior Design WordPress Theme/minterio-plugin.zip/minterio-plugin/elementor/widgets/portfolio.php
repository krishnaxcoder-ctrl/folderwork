<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio Portfolio Widget.
 *
 * @since 1.0
 */
class Minterio_Portfolio_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-portfolio';
	}

	public function get_title() {
		return esc_html__( 'Portfolio', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'heading_tab',
			[
				'label' => esc_html__( 'Heading', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'minterio-plugin' ),
				'type'        => Controls_Manager::WYSIWYG,
				'placeholder' => esc_html__( 'Enter description', 'minterio-plugin' ),
				'default'     => esc_html__( 'Description', 'minterio-plugin' ),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'filters_tab',
			[
				'label' => esc_html__( 'Filters', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'filters_note',
			[
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw' => esc_html__( 'Filters show only with pagination "Infinite Scrolling", "Button" or "No"', 'minterio-plugin' ),
				'content_classes' => 'elementor-descriptor',
			]
		);

		$this->add_control(
			'filters',
			[
				'label' => esc_html__( 'Show Filters', 'minterio-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'minterio-plugin' ),
				'label_off' => __( 'Hide', 'minterio-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_tab',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'source',
			[
				'label'       => esc_html__( 'Source', 'minterio-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'all',
				'options' => [
					'all'  => __( 'All', 'minterio-plugin' ),
					'categories' => __( 'Categories', 'minterio-plugin' ),
				],
			]
		);

		$this->add_control(
			'source_categories',
			[
				'label'       => esc_html__( 'Source', 'minterio-plugin' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple' => true,
				'options' => $this->get_portfolio_categories(),
				'condition' => [
		            'source' => 'categories'
		        ],
			]
		);

		$this->add_control(
			'limit',
			[
				'label'       => esc_html__( 'Number of Items', 'minterio-plugin' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => 8,
				'default'     => 8,
			]
		);

		$this->add_control(
			'sort',
			[
				'label'       => esc_html__( 'Sorting By', 'minterio-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'menu_order',
				'options' => [
					'date'  => __( 'Date', 'minterio-plugin' ),
					'title' => __( 'Title', 'minterio-plugin' ),
					'rand' => __( 'Random', 'minterio-plugin' ),
					'menu_order' => __( 'Order', 'minterio-plugin' ),
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label'       => esc_html__( 'Order', 'minterio-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'asc',
				'options' => [
					'asc'  => __( 'ASC', 'minterio-plugin' ),
					'desc' => __( 'DESC', 'minterio-plugin' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'settings_tab',
			[
				'label' => esc_html__( 'Settings', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'layout',
			[
				'label'       => esc_html__( 'Layout', 'minterio-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'columns-3',
				'options' => [
					'columns-2'  => __( 'Columns 2', 'minterio-plugin' ),
					'columns-3' => __( 'Columns 3', 'minterio-plugin' ),
					'columns-4' => __( 'Columns 4', 'minterio-plugin' ),
				],
			]
		);

		$this->add_control(
			'pagination',
			[
				'label'       => esc_html__( 'Pagination', 'minterio-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'no',
				'options' => [
					'no'  => __( 'No', 'minterio-plugin' ),
					'pages' => __( 'Pages', 'minterio-plugin' ),
				],
			]
		);

		$this->add_control(
			'show_title',
			[
				'label'       => esc_html__( 'Show Title?', 'minterio-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'yes',
				'options' => [
					'no'  => __( 'No', 'minterio-plugin' ),
					'yes' => __( 'Yes', 'minterio-plugin' ),
				],
			]
		);

		$this->add_control(
			'show_subtitle',
			[
				'label'       => esc_html__( 'Show Subtitle?', 'minterio-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'yes',
				'options' => [
					'no'  => __( 'No', 'minterio-plugin' ),
					'yes' => __( 'Yes', 'minterio-plugin' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'heading_styling',
			[
				'label'     => esc_html__( 'Heading Styling', 'minterio-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .sub-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'label'     => esc_html__( 'Title Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .sub-title',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Description Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .section-title > .description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'label'     => esc_html__( 'Description Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .section-title > .description',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'filters_styling',
			[
				'label'     => esc_html__( 'Filters', 'minterio-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'filters_color',
			[
				'label'     => esc_html__( 'Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .option-set li a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'filters_active_color',
			[
				'label'     => esc_html__( 'Active Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .option-set li a.selected' => 'color: {{VALUE}};',
					'{{WRAPPER}} .option-set li a.selected' => 'border-bottom-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'filters_typography',
				'selector' => '{{WRAPPER}} .option-set li a',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_styling',
			[
				'label'     => esc_html__( 'Items', 'minterio-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'item_title_color',
			[
				'label'     => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .project-info > h3 a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'item_title_typography',
				'label'     => esc_html__( 'Title Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .project-info > h3',
			]
		);

		$this->add_control(
			'item_subtitle_color',
			[
				'label'     => esc_html__( 'Subtitle Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .project-info > span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'item_subtitle_typography',
				'label'     => esc_html__( 'Subtitle Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .project-info > span',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render Categories List.
	 *
	 * @since 1.0
	 */
	protected function get_portfolio_categories() {
		$categories = [];

		$args = array(
			'type'			=> 'post',
			'child_of'		=> 0,
			'parent'		=> '',
			'orderby'		=> 'name',
			'order'			=> 'DESC',
			'hide_empty'	=> 1,
			'hierarchical'	=> 1,
			'taxonomy'		=> 'portfolio_categories',
			'pad_counts'	=> false
		);

		$portfolio_categories = get_categories( $args );

		foreach ( $portfolio_categories as $category ) {
			$categories[$category->term_id] = $category->name;
		}

		return $categories;
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'title', 'basic' );
		$this->add_inline_editing_attributes( 'description', 'advanced' );

		$paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
		$page_id = get_the_ID();

		if ( $settings['source'] == 'all' ) {
			$cat_ids = '';
		} else {
			$cat_ids = $settings['source_categories'];
		}

		$cat_args = array(
			'type'			=> 'post',
			'child_of'		=> 0,
			'parent'		=> '',
			'orderby'		=> 'name',
			'order'			=> 'DESC',
			'hide_empty'	=> 1,
			'hierarchical'	=> 1,
			'taxonomy'		=> 'portfolio_categories',
			'pad_counts'	=> false,
			'include'		=> $cat_ids
		);

		$pf_categories = get_categories( $cat_args );

		$args = array(
			'post_type'			=> 'portfolio',
			'post_status'		=> 'publish',
			'orderby'			=> $settings['sort'],
			'order'				=> $settings['order'],
			'posts_per_page'	=> $settings['limit'],
			'paged' 			=> $paged
		);

		if( $settings['source'] == 'categories' ) {
			$tax_array = array(
				array(
					'taxonomy' => 'portfolio_categories',
					'field'    => 'id',
					'terms'    => $cat_ids
				)
			);

			$args += array('tax_query' => $tax_array);
		}

		$q = new \WP_Query( $args );

		$temp = 'portfolio';

		$item_classes = '';

		if ( $settings['show_title'] == 'no' ) :
			$item_classes .= ' hide_title';
		endif;
		if ( $settings['show_subtitle'] == 'no' ) :
			$item_classes .= ' hide_subtitle';
		endif;
		if ( $settings['show_title'] == 'no' && $settings['show_category'] == 'no' ) :
			$item_classes .= ' hide_description';
		endif;

		?>

		<section class="page-content">
			<div class="container">
				<div class="portfolio-page">
					<?php if ( $settings['title'] || $settings['description'] ) : ?>
					<div class="section-title">
						<?php if ( $settings['title'] ) : ?>
						<h3 class="sub-title w-100">
							<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
								<?php echo wp_kses_post( $settings['title'] ); ?>
							</span>
						</h3>
						<?php endif; ?>
						<?php if ( $settings['description'] ) : ?>
						<div class="description">
							<div <?php echo $this->get_render_attribute_string( 'description' ); ?>>
								<?php echo wp_kses_post( $settings['description'] ); ?>
							</div>
						</div>
						<?php endif; ?>
					</div><!--section-title end-->
					<?php endif; ?>
					<?php if ( $settings['filters'] && $pf_categories && $settings['pagination'] != 'pages' ) : ?>
					<div class="options">
						<div class="option-isotop text-left">
							<ul id="filter" class="option-set filters-nav" data-option-key="filter">
								<li><a data-option-value="*" class="selected"><?php echo esc_html__( 'All', 'minterio-plugin' ); ?></a></li>
								<?php foreach ( $pf_categories as $category ) : ?>
								<li><a data-option-value=".sorting-<?php echo esc_attr( $category->slug ); ?>"><?php echo esc_html( $category->name ); ?></a></li>
								<?php endforeach; ?>
							</ul>
						</div>
					</div><!--isotope options end-->
					<?php endif; ?>
					<?php if ( $q->have_posts() ) : ?>
					<div class="row <?php echo esc_html( $item_classes ); ?>">
						<div class="masonary">
							<?php while ( $q->have_posts() ) : $q->the_post();
								set_query_var( 'layout', $settings['layout'] );
								get_template_part( 'template-parts/content', $temp );
							endwhile; ?>
						</div><!--masonary end-->
					</div>

					<?php if ( $settings['pagination'] == 'pages' ) : ?>
					<div class="pagination-minterio">
						<?php
							$big = 999999999; // need an unlikely integer

							echo paginate_links( array(
								'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
								'format' => '?paged=%#%',
								'current' => max( 1, get_query_var('paged') ),
								'total' => $q->max_num_pages,
								'prev_text' => esc_html__( 'Prev', 'minterio-plugin' ),
								'next_text' => esc_html__( 'Next', 'minterio-plugin' ),
							) );
						?>
					</div>
					<?php endif; ?>

					<?php else :
						get_template_part( 'template-parts/content', 'none' );
					endif; wp_reset_postdata(); ?>
				</div><!--portfolio-page end-->
			</div>
		</section><!--page-content end-->

		<?php
	}
}

Plugin::instance()->widgets_manager->register( new Minterio_Portfolio_Widget() );
