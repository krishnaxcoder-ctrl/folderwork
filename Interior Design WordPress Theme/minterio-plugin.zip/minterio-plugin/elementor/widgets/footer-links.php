<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio Footer Links Widget.
 *
 * @since 1.0
 */

class Minterio_Footer_Links_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-footer-links';
	}

	public function get_title() {
		return esc_html__( 'Footer Links', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'items_tab',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'text', [
				'label'       => esc_html__( 'Text', 'minterio-plugin' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter text', 'minterio-plugin' ),
				'default' => esc_html__( 'Text', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'link', [
				'label' => esc_html__( 'URL', 'minterio-plugin' ),
				'label_block' => true,
				'type' => Controls_Manager::URL,
				'show_external' => false,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'items',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ text }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_styling',
			[
				'label' => esc_html__( 'Content Styling', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'item_color',
			[
				'label' => esc_html__( 'Item Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .btm-links li a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_typography',
				'label' => esc_html__( 'Item Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .btm-links li',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<div class="widget">
			<?php if ( $settings['items'] ) : ?>
			<ul class="btm-links">
				<?php foreach ( $settings['items'] as $index => $item ) :
			    	$item_text = $this->get_repeater_setting_key( 'text', 'items', $index );
			    	$this->add_inline_editing_attributes( $item_text, 'basic' );
			    ?>
				<li>
					<a<?php if ( $item['link'] ) : ?><?php if ( $item['link']['is_external'] ) : ?> target="_blank"<?php endif; ?><?php if ( $item['link']['nofollow'] ) : ?> rel="nofollow"<?php endif; ?> href="<?php echo esc_url( $item['link']['url'] ); ?>"<?php endif; ?>>
						<span <?php echo $this->get_render_attribute_string( $item_text ); ?>>
							<?php echo wp_kses_post( $item['text'] ); ?>
						</span>
					</a>
				</li>
				<?php endforeach; ?>
			</ul><!--btm-links end-->
			<?php endif; ?>
		</div>

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() { ?>

		<div class="widget">
			<# if ( settings.items ) { #>
			<ul class="btm-links">
				<# _.each( settings.items, function( item, index ) {
					var item_text = view.getRepeaterSettingKey( 'text', 'items', index );
				    view.addInlineEditingAttributes( item_text, 'basic' );
				#>
				<li>
					<a<# if ( item.link ) { #><# if ( item.link.is_external ) { #> target="_blank"<# } #><# if ( item.link.nofollow ) { #> rel="nofollow"<# } #> href="{{{ item.link.url }}}"<# } #>>
						<span {{{ view.getRenderAttributeString( item_text ) }}}>
							{{{ item.text }}}
						</span>
					</a>
				</li>
				<# }); #>
			</ul><!--ft-links end-->
			<# } #>
		</div><!--widget-contact end-->

	<?php }
}

Plugin::instance()->widgets_manager->register( new Minterio_Footer_Links_Widget() );
