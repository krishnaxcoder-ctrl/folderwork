<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio Started Widget.
 *
 * @since 1.0
 */
class Minterio_Started_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-started';
	}

	public function get_title() {
		return esc_html__( 'Started', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'content_tab',
			[
				'label' => esc_html__( 'Content', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'subtitle',
			[
				'label'       => esc_html__( 'Subtitle', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter subtitle', 'minterio-plugin' ),
				'default'     => esc_html__( 'Subtitle', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'breadcrumbs',
			[
				'label' => esc_html__( 'Show Breadcrumbs', 'minterio-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'minterio-plugin' ),
				'label_off' => __( 'Hide', 'minterio-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'bgimages', [
				'label' => esc_html__( 'Background Image', 'minterio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri() . '/assets/images/main-banner-bg.jpg',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'media_tab',
			[
				'label' => esc_html__( 'Media', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'layout',
			[
				'label'       => esc_html__( 'Layout', 'minterio-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'style-2',
				'options' => [
					'style-1'  => __( 'Style 1', 'minterio-plugin' ),
					'style-2' => __( 'Style 2', 'minterio-plugin' ),
				],
			]
		);

		$this->add_control(
			'image',
			[
				'label'       => esc_html__( 'Image', 'minterio-plugin' ),
				'type'        => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'image2',
			[
				'label'       => esc_html__( 'Image', 'minterio-plugin' ),
				'type'        => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
            		'layout' => 'style-1'
        		],
			]
		);

		$this->add_control(
			'video',
			[
				'label' => esc_html__( 'Show Video', 'minterio-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'minterio-plugin' ),
				'label_off' => __( 'Hide', 'minterio-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
            		'layout' => 'style-1'
        		],
			]
		);

		$this->add_control(
			'video_yt_id',
			[
				'label'       => esc_html__( 'Youtube (Video ID)', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter Video ID', 'minterio-plugin' ),
				'default'     => esc_html__( 'pNxqh-JCMpw', 'minterio-plugin' ),
				'condition' => [
		            'video' => 'yes',
		            'layout' => 'style-1'
		        ],
			]
		);

		$this->add_control(
			'video_title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
				'condition' => [
		            'video' => 'yes',
		            'layout' => 'style-1'
		        ],
			]
		);

		$this->add_control(
			'video_button',
			[
				'label'       => esc_html__( 'Button', 'minterio-plugin' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter label', 'minterio-plugin' ),
				'default'     => esc_html__( 'Play video', 'minterio-plugin' ),
				'condition' => [
		            'video' => 'yes',
		            'layout' => 'style-1'
		        ],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'title_styling',
			[
				'label'     => esc_html__( 'Title', 'minterio-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .pager-info > h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'label'     => esc_html__( 'Title Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .pager-info > h2',
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'label'     => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .pager-info > span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'subtitle_typography',
				'label'     => esc_html__( 'Title Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .pager-info > span',
			]
		);

		$this->add_control(
			'video_title_color',
			[
				'label'     => esc_html__( 'Video Title Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .abt-txt > h4' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'video_title_typography',
				'label'     => esc_html__( 'Video Title Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .abt-txt > h4',
			]
		);

		$this->add_control(
			'video_button_color',
			[
				'label'     => esc_html__( 'Video Button Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .abt-txt > span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'video_button_typography',
				'label'     => esc_html__( 'Video Button Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .abt-txt > span',
			]
		);

		$this->end_controls_section();
	}


	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'title', 'basic' );
		$this->add_inline_editing_attributes( 'subtitle', 'basic' );
		$this->add_inline_editing_attributes( 'video_title', 'basic' );
		$this->add_inline_editing_attributes( 'video_button', 'basic' );

		$page_id = get_the_ID();

		?>

		<section class="pager-section" <?php if ( $settings['bgimages'] ) : ?>style="background-image: url(<?php echo esc_url( $settings['bgimages']['url'] ); ?>);"<?php endif; ?>>
			<div class="container">
				<div class="pager-info">
					<?php if ( $settings['breadcrumbs'] == 'yes' ) :
						minterio_breadcrumbs( $page_id );
					endif; ?>
					<?php if ( $settings['title'] ) : ?>
					<h2>
						<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
							<?php echo wp_kses_post( $settings['title'] ); ?>
						</span>
					</h2>
					<?php endif; ?>
					<?php if ( $settings['subtitle'] ) : ?>
					<span>
						<span <?php echo $this->get_render_attribute_string( 'subtitle' ); ?>>
							<?php echo wp_kses_post( $settings['subtitle'] ); ?>
						</span>
					</span>
					<?php endif; ?>
				</div>
				<div class="pger-imgs<?php if ( $settings['layout'] == 'style-2' ) : ?> style2<?php endif; ?>">
					<div class="abt-imgz">
						<?php if ( $settings['image'] ) : $image = wp_get_attachment_image_url( $settings['image']['id'], 'minterio_900xAuto' ); ?>
						<img src="<?php echo esc_url( $image ); ?>" alt="" />
						<?php endif; ?>
						<?php if ( $settings['layout'] == 'style-1' ) : ?>
						<?php if ( $settings['image2'] ) : $image = wp_get_attachment_image_url( $settings['image2']['id'], 'minterio_900xAuto' ); ?>
						<img src="<?php echo esc_url( $image ); ?>" alt="" class="sncd-img" />
						<?php endif; ?>
						<?php if ( $settings['video'] == 'yes' ) : ?>
						<div class="abt-txt">
							<?php if ( $settings['video_title'] ) : ?>
							<h4>
								<span <?php echo $this->get_render_attribute_string( 'video_title' ); ?>>
									<?php echo wp_kses_post( $settings['video_title'] ); ?>
								</span>
							</h4>
							<?php endif; ?>
							<?php if ( $settings['video_button'] ) : ?>
							<span>
								<span <?php echo $this->get_render_attribute_string( 'video_button' ); ?>>
									<?php echo wp_kses_post( $settings['video_button'] ); ?>
								</span>
							</span>
							<?php endif; ?>
							<a href="https://www.youtube.com/watch?v=<?php echo esc_attr( $settings['video_yt_id'] ); ?>" title="" class="play-btn has-popup-video"><i class="fa fa-play"></i></a>
						</div>
						<?php endif; ?>
						<?php endif; ?>
					</div>
				</div><!--pger-imgs end-->
				<div class="clearfix"></div>
			</div>
		</section><!--pager-section end-->

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() { ?>

	<#
	view.addInlineEditingAttributes( 'title', 'basic' );
	view.addInlineEditingAttributes( 'subtitle', 'basic' );
	view.addInlineEditingAttributes( 'video_title', 'basic' );
	view.addInlineEditingAttributes( 'video_button', 'basic' );
	#>

	<section class="pager-section" <# if ( settings.bgimages ) { #>style="background-image: url({{{ settings.bgimages.url }}}"<# } #>>
		<div class="container">
			<div class="pager-info">
				<# if ( settings.breadcrumbs == 'yes' ) { #>
					[breadcrumbs]
				<# } #>
				<# if ( settings.title ) { #>
				<h2>
					<span {{{ view.getRenderAttributeString( 'title' ) }}}>{{{ settings.title }}}</span>
				</h2>
				<# } #>
				<# if ( settings.subtitle ) { #>
				<span>
					<span {{{ view.getRenderAttributeString( 'subtitle' ) }}}>{{{ settings.subtitle }}}</span>
				</span>
				<# } #>
			</div>
			<div class="pger-imgs<# if ( settings.layout == 'style-2' ) { #> style2<# } #>">
				<div class="abt-imgz">
					<# if ( settings.image ) { #>
					<img src="{{{ settings.image.url }}}" alt="" />
					<# } #>
					<# if ( settings.layout == 'style-1' ) { #>
					<# if ( settings.image2 ) { #>
					<img src="{{{ settings.image2.url }}}" alt="" class="sncd-img" />
					<# } #>
					<# if ( settings.video == 'yes' ) { #>
					<div class="abt-txt">
						<# if ( settings.video_title ) { #>
						<h4>
							<span {{{ view.getRenderAttributeString( 'video_title' ) }}}>{{{ settings.video_title }}}</span>
						</h4>
						<# } #>
						<# if ( settings.video_button ) { #>
						<span>
							<span {{{ view.getRenderAttributeString( 'video_button' ) }}}>{{{ settings.video_button }}}</span>
						</span>
						<# } #>
						<a href="https://www.youtube.com/watch?v={{{ settings.video_yt_id }}}" title="" class="play-btn html5lightbox"><i class="fa fa-play"></i></a>
					</div>
					<# } #>
					<# } #>
				</div>
			</div><!--pger-imgs end-->
			<div class="clearfix"></div>
		</div>
	</section><!--pager-section end-->

	<?php }
}

Plugin::instance()->widgets_manager->register( new Minterio_Started_Widget() );
