<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio Numbers Widget.
 *
 * @since 1.0
 */

class Minterio_Numbers_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-numbers';
	}

	public function get_title() {
		return esc_html__( 'Numbers', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'heading_tab',
			[
				'label' => esc_html__( 'Heading', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'bgimages', [
				'label' => esc_html__( 'Background Image', 'minterio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri() . '/assets/images/main-banner-bg.jpg',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_tab',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'value', [
				'label'       => esc_html__( 'Value', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter value', 'minterio-plugin' ),
				'default' => esc_html__( '10', 'minterio-plugin' ),
			]
		);

		$repeater->add_control(
			'label', [
				'label'       => esc_html__( 'Label', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter label', 'minterio-plugin' ),
				'default' => esc_html__( 'Enter label', 'minterio-plugin' ),
			]
		);

		$this->add_control(
			'items',
			[
				'label' => esc_html__( 'Numbers Items', 'minterio-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ label }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'heading_styling',
			[
				'label' => esc_html__( 'Heading', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .sub-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Title Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .sub-title',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_styling',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'item_value_color',
			[
				'label' => esc_html__( 'Value Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .award-col > h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_value_typography',
				'label' => esc_html__( 'Value Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .award-col > h2',
			]
		);

		$this->add_control(
			'item_label_color',
			[
				'label' => esc_html__( 'Label Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .award-col > h3' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_label_typography',
				'label' => esc_html__( 'Label Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .award-col > h3',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'title', 'basic' );

		?>

		<section class="block2">
			<div class="fixed-bg" <?php if ( $settings['bgimages'] ) : ?>style="background-image: url(<?php echo esc_url( $settings['bgimages']['url'] ); ?>);"<?php endif; ?>></div>
			<div class="container">
				<div class="arch-section">
					<div class="row">
						<?php if ( $settings['title'] ) : ?>
						<div class="col-lg-4">
							<h3 class="sub-title m-0">
								<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
									<?php echo wp_kses_post( $settings['title'] ); ?>
								</span>
							</h3>
						</div>
						<?php endif; ?>
						<div class="col-lg-8">
							<div class="our-awards-sec">
								<?php if ( $settings['items'] ) : ?>
								<div class="row">
									<?php
								    foreach ( $settings['items'] as $index => $item ) :
								        $item_value = $this->get_repeater_setting_key( 'value', 'items', $index );
								    	$this->add_inline_editing_attributes( $item_value, 'basic' );

								        $item_label = $this->get_repeater_setting_key( 'label', 'items', $index );
								    	$this->add_inline_editing_attributes( $item_label, 'basic' );
								    ?>
									<div class="col-lg-3 col-md-3 col-sm-6">
										<div class="award-col">
											<?php if ( $item['value'] ) : ?>
											<h2 class="count">
												<span <?php echo $this->get_render_attribute_string( $item_value ); ?>>
													<?php echo wp_kses_post( $item['value'] ); ?>
												</span>
											</h2>
											<?php endif; ?>
											<?php if ( $item['label'] ) : ?>
											<h3>
												<span <?php echo $this->get_render_attribute_string( $item_label ); ?>>
													<?php echo wp_kses_post( $item['label'] ); ?>
												</span>
											</h3>
											<?php endif; ?>
										</div><!--award-col end-->
									</div>
									<?php endforeach; ?>
								</div>
								<?php endif; ?>
							</div><!--our-awards-sec end-->
						</div>
					</div>
				</div><!--arch-section end-->
			</div>
		</section>

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() { ?>

		<#
		view.addInlineEditingAttributes( 'title', 'basic' );
		#>

		<section class="block2">
			<div class="fixed-bg" <# if ( settings.bgimages ) { #>style="background-image: url({{{ settings.bgimages.url }}}"<# } #>></div>
			<div class="container">
				<div class="arch-section">
					<div class="row">
						<# if ( settings.title ) { #>
						<div class="col-lg-4">
							<h3 class="sub-title m-0">
								<span {{{ view.getRenderAttributeString( 'title' ) }}}>{{{ settings.title }}}</span>
							</h3>
						</div>
						<# } #>
						<div class="col-lg-8">
							<div class="our-awards-sec">
								<# if ( settings.items ) { #>
								<div class="row">
									<# _.each( settings.items, function( item, index ) {
								        var item_value = view.getRepeaterSettingKey( 'value', 'items', index );
								    	view.addInlineEditingAttributes( item_value, 'basic' );

								        var item_label = view.getRepeaterSettingKey( 'label', 'items', index );
								    	view.addInlineEditingAttributes( item_label, 'basic' );
								    #>
									<div class="col-lg-3 col-md-3 col-sm-6">
										<div class="award-col">
											<# if ( item.value ) { #>
											<h2 class="count">
												<span {{{ view.getRenderAttributeString( item_value ) }}}>{{{ item.value }}}</span>
											</h2>
											<# } #>
											<# if ( item.label ) { #>
											<h3>
												<span {{{ view.getRenderAttributeString( item_label ) }}}>{{{ item.label }}}</span>
											</h3>
											<# } #>
										</div><!--award-col end-->
									</div>
									<# }); #>
								</div>
								<# } #>
							</div><!--our-awards-sec end-->
						</div>
					</div>
				</div><!--arch-section end-->
			</div>
		</section>

	<?php }
}

Plugin::instance()->widgets_manager->register( new Minterio_Numbers_Widget() );
