<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio Footer Subscribe Widget.
 *
 * @since 1.0
 */

class Minterio_Footer_Subscribe_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-footer-subscribe';
	}

	public function get_title() {
		return esc_html__( 'Footer Subscribe', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'content_tab',
			[
				'label' => esc_html__( 'Heading', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description (Before)', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter description', 'minterio-plugin' ),
				'default'     => '',
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'form_tab',
			[
				'label' => esc_html__( 'Form', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'form',
			[
				'label' => esc_html__( 'Select CF7 Form', 'minterio-plugin' ),
				'type' => Controls_Manager::SELECT,
				'default' => 1,
				'options' => $this->contact_form_list(),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_styling',
			[
				'label' => esc_html__( 'Content', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .widget-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Title Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .widget-title',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label' => esc_html__( 'Description Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .widget-info > .description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'label' => esc_html__( 'Description Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .widget-info > .description',
			]
		);

		$this->add_control(
			'form_color',
			[
				'label' => esc_html__( 'Form Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .widget-form input' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .widget-form input' => 'color: {{VALUE}};',
					'{{WRAPPER}} .widget-form button' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render Contact Form List.
	 *
	 * @since 1.0
	 */
	protected function contact_form_list() {
		$cf7_posts = get_posts( 'post_type="wpcf7_contact_form"&numberposts=-1' );

		$cf7_forms = array();

		if ( $cf7_posts ) {
			foreach ( $cf7_posts as $cf7_form ) {
				$cf7_forms[ $cf7_form->ID ] = $cf7_form->post_title;
			}
		} else {
			$cf7_forms[ esc_html__( 'No contact forms found', 'minterio-plugin' ) ] = 0;
		}

		return $cf7_forms;
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'title', 'basic' );
		$this->add_inline_editing_attributes( 'description', 'basic' );

		?>

		<div class="widget widget-info">
			<?php if ( $settings['title'] ) : ?>
			<h3 class="widget-title">
				<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
					<?php echo wp_kses_post( $settings['title'] ); ?>
				</span>
			</h3>
			<?php endif; ?>
			<?php if ( $settings['form'] ) : ?>
			<div class="widget-form">
				<?php echo do_shortcode( '[contact-form-7 id="'. esc_attr( $settings['form'] ) .'"]' ); ?>
			</div>
			<?php endif; ?>
			<?php if ( $settings['description'] ) : ?>
			<span class="description">
				<span <?php echo $this->get_render_attribute_string( 'description' ); ?>>
					<?php echo wp_kses_post( $settings['description'] ); ?>
				</span>
			</span>
			<?php endif; ?>
		</div><!--widget-info end-->

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() { ?>

		<#
		view.addInlineEditingAttributes( 'title', 'basic' );
		view.addInlineEditingAttributes( 'description', 'basic' );
		#>

		<div class="widget widget-info">
			<# if( settings.title ) { #>
			<h3 class="widget-title">
				<span {{{ view.getRenderAttributeString( 'title' ) }}}>{{{ settings.title }}}</span>
			</h3>
			<# } #>
			<# if ( settings.form ) { #>
			<div class="widget-form">
				[contact-form-7 id="{{{ settings.form }}}"]
			</div>
			<# } #>
			<# if( settings.description ) { #>
			<span class="description">
				<span {{{ view.getRenderAttributeString( 'description' ) }}}>{{{ settings.description }}}</span>
			</span>
			<# } #>
		</div><!--widget-info end-->

	<?php }
}

Plugin::instance()->widgets_manager->register( new Minterio_Footer_Subscribe_Widget() );
