<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio Services Table Widget.
 *
 * @since 1.0
 */

class Minterio_Services_Table_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-services-table';
	}

	public function get_title() {
		return esc_html__( 'Services (Table)', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'heading_tab',
			[
				'label' => esc_html__( 'Heading', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'bgimages', [
				'label' => esc_html__( 'Background Image', 'minterio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri() . '/assets/images/main-banner-bg.jpg',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_col1_tab',
			[
				'label' => esc_html__( 'Content Column #1', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'col1_show',
			[
				'label' => esc_html__( 'Column #1', 'minterio-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'minterio-plugin' ),
				'label_off' => __( 'Hide', 'minterio-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'col1_title',
			[
				'label'       => esc_html__( 'Column Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
			]
		);

		$this->add_control(
			'col1_title_num',
			[
				'label'       => esc_html__( 'Column Title Num', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter num', 'minterio-plugin' ),
				'default'     => esc_html__( '01.', 'minterio-plugin' ),
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'title', [
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default' => esc_html__( 'Enter title', 'minterio-plugin' ),
			]
		);

		$repeater->add_control(
			'text', [
				'label'       => esc_html__( 'Text', 'minterio-plugin' ),
				'type'        => Controls_Manager::WYSIWYG,
				'placeholder' => esc_html__( 'Enter text', 'minterio-plugin' ),
				'default' => esc_html__( 'Enter text', 'minterio-plugin' ),
			]
		);

		$this->add_control(
			'items',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_col2_tab',
			[
				'label' => esc_html__( 'Content Column #2', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'col2_show',
			[
				'label' => esc_html__( 'Column #2', 'minterio-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'minterio-plugin' ),
				'label_off' => __( 'Hide', 'minterio-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'col2_title',
			[
				'label'       => esc_html__( 'Column Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
			]
		);

		$this->add_control(
			'col2_title_num',
			[
				'label'       => esc_html__( 'Column Title Num', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter num', 'minterio-plugin' ),
				'default'     => esc_html__( '01.', 'minterio-plugin' ),
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'title', [
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default' => esc_html__( 'Enter title', 'minterio-plugin' ),
			]
		);

		$repeater->add_control(
			'text', [
				'label'       => esc_html__( 'Text', 'minterio-plugin' ),
				'type'        => Controls_Manager::WYSIWYG,
				'placeholder' => esc_html__( 'Enter text', 'minterio-plugin' ),
				'default' => esc_html__( 'Enter text', 'minterio-plugin' ),
			]
		);

		$this->add_control(
			'items2',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_col3_tab',
			[
				'label' => esc_html__( 'Content Column #3', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'col3_show',
			[
				'label' => esc_html__( 'Column #3', 'minterio-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'minterio-plugin' ),
				'label_off' => __( 'Hide', 'minterio-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'col3_title',
			[
				'label'       => esc_html__( 'Column Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
			]
		);

		$this->add_control(
			'col3_title_num',
			[
				'label'       => esc_html__( 'Column Title Num', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter num', 'minterio-plugin' ),
				'default'     => esc_html__( '01.', 'minterio-plugin' ),
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'title', [
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default' => esc_html__( 'Enter title', 'minterio-plugin' ),
			]
		);

		$repeater->add_control(
			'text', [
				'label'       => esc_html__( 'Text', 'minterio-plugin' ),
				'type'        => Controls_Manager::WYSIWYG,
				'placeholder' => esc_html__( 'Enter text', 'minterio-plugin' ),
				'default' => esc_html__( 'Enter text', 'minterio-plugin' ),
			]
		);

		$this->add_control(
			'items3',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'heading_styling',
			[
				'label' => esc_html__( 'Heading', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .sub-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Title Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .sub-title',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_styling',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'col_title_color',
			[
				'label' => esc_html__( 'Column Title Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pro-head > h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'col_title_typography',
				'label' => esc_html__( 'Column Title Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .pro-head > h2',
			]
		);

		$this->add_control(
			'col_title_num_color',
			[
				'label' => esc_html__( 'Column Title Num Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pro-head > h2 strong' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'col_title_num_typography',
				'label' => esc_html__( 'Column Title Num Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .pro-head > h2 strong',
			]
		);

		$this->add_control(
			'item_title_color',
			[
				'label' => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pz-head > h3' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_title_typography',
				'label' => esc_html__( 'Title Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .pz-head > h3',
			]
		);

		$this->add_control(
			'item_text_color',
			[
				'label' => esc_html__( 'Text Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .prc-sorw .description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_text_typography',
				'label' => esc_html__( 'Text Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .prc-sorw .description',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'title', 'basic' );
		$this->add_inline_editing_attributes( 'col1_title', 'basic' );
		$this->add_inline_editing_attributes( 'col1_title_num', 'basic' );
		$this->add_inline_editing_attributes( 'col2_title', 'basic' );
		$this->add_inline_editing_attributes( 'col2_title_num', 'basic' );
		$this->add_inline_editing_attributes( 'col3_title', 'basic' );
		$this->add_inline_editing_attributes( 'col3_title_num', 'basic' );

		?>

		<section class="block">
			<div class="fixed-bg" <?php if ( $settings['bgimages'] ) : ?>style="background-image: url(<?php echo esc_url( $settings['bgimages']['url'] ); ?>);"<?php endif; ?>></div>
			<div class="container">
				<?php if ( $settings['title'] ) : ?>
				<h3 class="sub-title mw-45 mgb-100">
					<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
						<?php echo wp_kses_post( $settings['title'] ); ?>
					</span>
				</h3><!--sub-title end-->
				<?php endif; ?>

				<div class="processs-section">
					<div class="row">
						<?php if ( $settings['items'] && $settings['col1_show'] == 'yes' ) : ?>
						<div class="col-lg-4 col-md-6 col-sm-12">
							<div class="process-col">
								<?php if ( $settings['col1_title'] ) : ?>
								<div class="pro-head">
									<h2>
										<span <?php echo $this->get_render_attribute_string( 'col1_title' ); ?>>
											<?php echo wp_kses_post( $settings['col1_title'] ); ?>
										</span>
										<?php if ( $settings['col1_title_num'] ) : ?>
										<strong>
											<span <?php echo $this->get_render_attribute_string( 'col1_title_num' ); ?>>
												<?php echo wp_kses_post( $settings['col1_title_num'] ); ?>
											</span>
										</strong>
										<?php endif; ?>
									</h2>
								</div>
								<?php endif; ?>
								<?php if ( $settings['items'] ) : ?>
								<ul>
									<?php foreach ( $settings['items'] as $index => $item ) :
								    	$item_title = $this->get_repeater_setting_key( 'title', 'items', $index );
								    	$this->add_inline_editing_attributes( $item_title, 'basic' );

								    	$item_text = $this->get_repeater_setting_key( 'text', 'items', $index );
								    	$this->add_inline_editing_attributes( $item_text, 'advanced' );
									?>
									<li>
										<div class="prc-sorw">
											<?php if ( $item['title'] ) : ?>
											<div class="pz-head">
												<h3>
													<span <?php echo $this->get_render_attribute_string( $item_title ); ?>>
														<?php echo wp_kses_post( $item['title'] ); ?>
													</span>
												</h3>
												<div class="dott"></div>
											</div>
											<?php endif; ?>
											<?php if ( $item['text'] ) : ?>
											<div class="description">
												<div <?php echo $this->get_render_attribute_string( $item_text ); ?>>
													<?php echo wp_kses_post( $item['text'] ); ?>
												</div>
											</div>
											<?php endif; ?>
										</div>
									</li>
									<?php endforeach; ?>
								</ul>
								<?php endif; ?>
							</div><!--process-col end-->
						</div>
						<?php endif; ?>
						<?php if ( $settings['items2'] && $settings['col2_show'] == 'yes' ) : ?>
						<div class="col-lg-4 col-md-6 col-sm-12">
							<div class="process-col">
								<?php if ( $settings['col2_title'] ) : ?>
								<div class="pro-head">
									<h2>
										<span <?php echo $this->get_render_attribute_string( 'col2_title' ); ?>>
											<?php echo wp_kses_post( $settings['col2_title'] ); ?>
										</span>
										<?php if ( $settings['col2_title_num'] ) : ?>
										<strong>
											<span <?php echo $this->get_render_attribute_string( 'col2_title_num' ); ?>>
												<?php echo wp_kses_post( $settings['col2_title_num'] ); ?>
											</span>
										</strong>
										<?php endif; ?>
									</h2>
								</div>
								<?php endif; ?>
								<?php if ( $settings['items2'] ) : ?>
								<ul>
									<?php foreach ( $settings['items2'] as $index => $item ) :
								    	$item_title2 = $this->get_repeater_setting_key( 'title', 'items2', $index );
								    	$this->add_inline_editing_attributes( $item_title2, 'basic' );

								    	$item_text2 = $this->get_repeater_setting_key( 'text', 'items2', $index );
								    	$this->add_inline_editing_attributes( $item_text2, 'advanced' );
									?>
									<li>
										<div class="prc-sorw">
											<?php if ( $item['title'] ) : ?>
											<div class="pz-head">
												<h3>
													<span <?php echo $this->get_render_attribute_string( $item_title2 ); ?>>
														<?php echo wp_kses_post( $item['title'] ); ?>
													</span>
												</h3>
												<div class="dott"></div>
											</div>
											<?php endif; ?>
											<?php if ( $item['text'] ) : ?>
											<div class="description">
												<div <?php echo $this->get_render_attribute_string( $item_text2 ); ?>>
													<?php echo wp_kses_post( $item['text'] ); ?>
												</div>
											</div>
											<?php endif; ?>
										</div>
									</li>
									<?php endforeach; ?>
								</ul>
								<?php endif; ?>
							</div><!--process-col end-->
						</div>
						<?php endif; ?>
						<?php if ( $settings['items3'] && $settings['col3_show'] == 'yes' ) : ?>
						<div class="col-lg-4 col-md-6 col-sm-12">
							<div class="process-col">
								<?php if ( $settings['col3_title'] ) : ?>
								<div class="pro-head">
									<h2>
										<span <?php echo $this->get_render_attribute_string( 'col3_title' ); ?>>
											<?php echo wp_kses_post( $settings['col3_title'] ); ?>
										</span>
										<?php if ( $settings['col3_title_num'] ) : ?>
										<strong>
											<span <?php echo $this->get_render_attribute_string( 'col3_title_num' ); ?>>
												<?php echo wp_kses_post( $settings['col3_title_num'] ); ?>
											</span>
										</strong>
										<?php endif; ?>
									</h2>
								</div>
								<?php endif; ?>
								<?php if ( $settings['items3'] ) : ?>
								<ul>
									<?php foreach ( $settings['items3'] as $index => $item ) :
								    	$item_title3 = $this->get_repeater_setting_key( 'title', 'items3', $index );
								    	$this->add_inline_editing_attributes( $item_title3, 'basic' );

								    	$item_text3 = $this->get_repeater_setting_key( 'text', 'items3', $index );
								    	$this->add_inline_editing_attributes( $item_text3, 'advanced' );
									?>
									<li>
										<div class="prc-sorw">
											<?php if ( $item['title'] ) : ?>
											<div class="pz-head">
												<h3>
													<span <?php echo $this->get_render_attribute_string( $item_title3 ); ?>>
														<?php echo wp_kses_post( $item['title'] ); ?>
													</span>
												</h3>
												<div class="dott"></div>
											</div>
											<?php endif; ?>
											<?php if ( $item['text'] ) : ?>
											<div class="description">
												<div <?php echo $this->get_render_attribute_string( $item_text3 ); ?>>
													<?php echo wp_kses_post( $item['text'] ); ?>
												</div>
											</div>
											<?php endif; ?>
										</div>
									</li>
									<?php endforeach; ?>
								</ul>
								<?php endif; ?>
							</div><!--process-col end-->
						</div>
						<?php endif; ?>
					</div>
				</div><!--process-section end-->
			</div>
		</section>

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() { ?>
		<#
		view.addInlineEditingAttributes( 'title', 'basic' );
		view.addInlineEditingAttributes( 'col1_title', 'basic' );
		view.addInlineEditingAttributes( 'col1_title_num', 'basic' );
		view.addInlineEditingAttributes( 'col2_title', 'basic' );
		view.addInlineEditingAttributes( 'col2_title_num', 'basic' );
		view.addInlineEditingAttributes( 'col3_title', 'basic' );
		view.addInlineEditingAttributes( 'col3_title_num', 'basic' );
		#>

		<section class="block">
			<div class="fixed-bg" <# if ( settings.bgimages ) { #>style="background-image: url({{{ settings.bgimages.url }}}"<# } #>></div>
			<div class="container">
				 <# if ( settings.title ) { #>
				<h3 class="sub-title mw-45 mgb-100">
					<span {{{ view.getRenderAttributeString( 'title' ) }}}>
        				{{{ settings.title }}}
        			</span>
				</h3><!--sub-title end-->
				<# } #>

				<div class="processs-section">
					<div class="row">
						<# if ( settings.items && settings.col1_show == 'yes' ) { #>
						<div class="col-lg-4 col-md-6 col-sm-12">
							<div class="process-col">
								<# if ( settings.col1_title ) { #>
								<div class="pro-head">
									<h2>
										<span {{{ view.getRenderAttributeString( 'col1_title' ) }}}>
					        				{{{ settings.col1_title }}}
					        			</span>
										<# if ( settings.col1_title_num ) { #>
										<strong>
											<span {{{ view.getRenderAttributeString( 'col1_title_num' ) }}}>
						        				{{{ settings.col1_title_num }}}
						        			</span>
										</strong>
										<# } #>
									</h2>
								</div>
								<# } #>
								<# if ( settings.items ) { #>
								<ul>
									<# _.each( settings.items, function( item, index ) {
										var item_title = view.getRepeaterSettingKey( 'title', 'items', index );
									    view.addInlineEditingAttributes( item_title, 'basic' );

									    var item_text = view.getRepeaterSettingKey( 'text', 'items', index );
									    view.addInlineEditingAttributes( item_text, 'advanced' );
									#>
									<li>
										<div class="prc-sorw">
											<# if ( item.title ) { #>
											<div class="pz-head">
												<h3>
													<span {{{ view.getRenderAttributeString( item_title ) }}}>
														{{{ item.title }}}
													</span>
												</h3>
												<div class="dott"></div>
											</div>
											<# } #>
											<# if ( item.text ) { #>
											<div class="description">
												<div {{{ view.getRenderAttributeString( item_text ) }}}>
													{{{ item.text }}}
												</div>
											</div>
											<# } #>
										</div>
									</li>
									<# }); #>
								</ul>
								<# } #>
							</div><!--process-col end-->
						</div>
						<# } #>
						<# if ( settings.items2 && settings.col2_show == 'yes' ) { #>
						<div class="col-lg-4 col-md-6 col-sm-12">
							<div class="process-col">
								<# if ( settings.col2_title ) { #>
								<div class="pro-head">
									<h2>
										<span {{{ view.getRenderAttributeString( 'col2_title' ) }}}>
					        				{{{ settings.col2_title }}}
					        			</span>
										<# if ( settings.col2_title_num ) { #>
										<strong>
											<span {{{ view.getRenderAttributeString( 'col2_title_num' ) }}}>
						        				{{{ settings.col2_title_num }}}
						        			</span>
										</strong>
										<# } #>
									</h2>
								</div>
								<# } #>
								<# if ( settings.items2 ) { #>
								<ul>
									<# _.each( settings.items2, function( item, index ) {
										var item_title2 = view.getRepeaterSettingKey( 'title', 'items2', index );
									    view.addInlineEditingAttributes( item_title2, 'basic' );

									    var item_text2 = view.getRepeaterSettingKey( 'text', 'items2', index );
									    view.addInlineEditingAttributes( item_text2, 'advanced' );
									#>
									<li>
										<div class="prc-sorw">
											<# if ( item.title ) { #>
											<div class="pz-head">
												<h3>
													<span {{{ view.getRenderAttributeString( item_title2 ) }}}>
														{{{ item.title }}}
													</span>
												</h3>
												<div class="dott"></div>
											</div>
											<# } #>
											<# if ( item.text ) { #>
											<div class="description">
												<div {{{ view.getRenderAttributeString( item_text2 ) }}}>
													{{{ item.text }}}
												</div>
											</div>
											<# } #>
										</div>
									</li>
									<# }); #>
								</ul>
								<# } #>
							</div><!--process-col end-->
						</div>
						<# } #>
						<# if ( settings.items3 && settings.col3_show == 'yes' ) { #>
						<div class="col-lg-4 col-md-6 col-sm-12">
							<div class="process-col">
								<# if ( settings.col3_title ) { #>
								<div class="pro-head">
									<h2>
										<span {{{ view.getRenderAttributeString( 'col3_title' ) }}}>
					        				{{{ settings.col3_title }}}
					        			</span>
										<# if ( settings.col3_title_num ) { #>
										<strong>
											<span {{{ view.getRenderAttributeString( 'col3_title_num' ) }}}>
						        				{{{ settings.col3_title_num }}}
						        			</span>
										</strong>
										<# } #>
									</h2>
								</div>
								<# } #>
								<# if ( settings.items3 ) { #>
								<ul>
									<# _.each( settings.items3, function( item, index ) {
										var item_title3 = view.getRepeaterSettingKey( 'title', 'items3', index );
									    view.addInlineEditingAttributes( item_title3, 'basic' );

									    var item_text3 = view.getRepeaterSettingKey( 'text', 'items3', index );
									    view.addInlineEditingAttributes( item_text3, 'advanced' );
									#>
									<li>
										<div class="prc-sorw">
											<# if ( item.title ) { #>
											<div class="pz-head">
												<h3>
													<span {{{ view.getRenderAttributeString( item_title3 ) }}}>
														{{{ item.title }}}
													</span>
												</h3>
												<div class="dott"></div>
											</div>
											<# } #>
											<# if ( item.text ) { #>
											<div class="description">
												<div {{{ view.getRenderAttributeString( item_text3 ) }}}>
													{{{ item.text }}}
												</div>
											</div>
											<# } #>
										</div>
									</li>
									<# }); #>
								</ul>
								<# } #>
							</div><!--process-col end-->
						</div>
						<# } #>
					</div>
				</div><!--process-section end-->
			</div>
		</section>

	<?php }
}

Plugin::instance()->widgets_manager->register( new Minterio_Services_Table_Widget() );
