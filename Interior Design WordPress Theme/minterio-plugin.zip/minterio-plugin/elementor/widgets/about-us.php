<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio About Us Widget.
 *
 * @since 1.0
 */
class Minterio_About_Us_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-about-us';
	}

	public function get_title() {
		return esc_html__( 'About Us', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'content_tab',
			[
				'label' => esc_html__( 'Content', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'minterio-plugin' ),
				'type'        => Controls_Manager::WYSIWYG,
				'placeholder' => esc_html__( 'Enter your description', 'minterio-plugin' ),
				'default'     => esc_html__( 'Description', 'minterio-plugin' ),
			]
		);

		$this->add_control(
			'button',
			[
				'label'       => esc_html__( 'Button (Text)', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter Button Label', 'minterio-plugin' ),
				'default'     => esc_html__( 'Button', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'link',
			[
				'label' => esc_html__( 'Button (URL)', 'minterio-plugin' ),
				'label_block' => true,
				'type' => Controls_Manager::URL,
				'show_external' => true,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'images_tab',
			[
				'label' => esc_html__( 'Images', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'image1',
			[
				'label'       => esc_html__( 'Image #1', 'minterio-plugin' ),
				'type'        => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'image2',
			[
				'label'       => esc_html__( 'Image #2', 'minterio-plugin' ),
				'type'        => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'video_tab',
			[
				'label' => esc_html__( 'Video', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'video',
			[
				'label' => esc_html__( 'Show Video', 'minterio-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'minterio-plugin' ),
				'label_off' => __( 'Hide', 'minterio-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'video_yt_id',
			[
				'label'       => esc_html__( 'Youtube (Video ID)', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter Video ID', 'minterio-plugin' ),
				'default'     => esc_html__( 'pNxqh-JCMpw', 'minterio-plugin' ),
				'condition' => [
		            'video' => 'yes'
		        ],
			]
		);

		$this->add_control(
			'video_title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
				'condition' => [
		            'video' => 'yes'
		        ],
			]
		);

		$this->add_control(
			'video_button',
			[
				'label'       => esc_html__( 'Button', 'minterio-plugin' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter label', 'minterio-plugin' ),
				'default'     => esc_html__( 'Play video', 'minterio-plugin' ),
				'condition' => [
		            'video' => 'yes'
		        ],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_styling',
			[
				'label'     => esc_html__( 'Content Styling', 'minterio-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .about-text .sub-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'label'     => esc_html__( 'Title Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .about-text .sub-title',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Description Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .about-text > .description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'label'     => esc_html__( 'Description Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .about-text > .description',
			]
		);

		$this->add_control(
			'button_color',
			[
				'label'     => esc_html__( 'Button Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .lnk-default2' => 'color: {{VALUE}};',
					'{{WRAPPER}} .lnk-default2:before' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'button_typography',
				'label'     => esc_html__( 'Button Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .lnk-default2',
			]
		);

		$this->add_control(
			'video_title_color',
			[
				'label'     => esc_html__( 'Video Title Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .abt-txt > h4' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'video_title_typography',
				'label'     => esc_html__( 'Video Title Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .abt-txt > h4',
			]
		);

		$this->add_control(
			'video_button_color',
			[
				'label'     => esc_html__( 'Video Button Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .abt-txt > span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'video_button_typography',
				'label'     => esc_html__( 'Video Button Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .abt-txt > span',
			]
		);

		$this->end_controls_section();
	}


	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'title', 'basic' );
		$this->add_inline_editing_attributes( 'description', 'advanced' );
		$this->add_inline_editing_attributes( 'button', 'basic' );
		$this->add_inline_editing_attributes( 'video_title', 'basic' );
		$this->add_inline_editing_attributes( 'video_button', 'basic' );

		?>

		<section class="block pb-0">
			<div class="container">
				<div class="about-us-section">
					<div class="row align-items-center">
						<div class="col-lg-6">
							<div class="abt-imgz">
								<?php if ( $settings['image1'] ) : $image = wp_get_attachment_image_url( $settings['image1']['id'], 'minterio_900xAuto' ); ?>
								<img class="wow fadeInUp" data-wow-duration="1000ms" src="<?php echo esc_url( $image ); ?>" alt="" />
								<?php endif; ?>
								<?php if ( $settings['image2'] ) : $image = wp_get_attachment_image_url( $settings['image2']['id'], 'minterio_900xAuto' ); ?>
								<img class="wow fadeInRight" data-wow-duration="1000ms" data-wow-delay="400ms" src="<?php echo esc_url( $image ); ?>" alt="" />
								<?php endif; ?>
							</div><!--abt-imgz end-->
							<?php if ( $settings['video'] == 'yes' ) : ?>
							<div class="abt-txt">
								<?php if ( $settings['video_title'] ) : ?>
								<h4>
									<span <?php echo $this->get_render_attribute_string( 'video_title' ); ?>>
										<?php echo wp_kses_post( $settings['video_title'] ); ?>
									</span>
								</h4>
								<?php endif; ?>
								<?php if ( $settings['video_button'] ) : ?>
								<span>
									<span <?php echo $this->get_render_attribute_string( 'video_button' ); ?>>
										<?php echo wp_kses_post( $settings['video_button'] ); ?>
									</span>
								</span>
								<?php endif; ?>
								<a href="https://www.youtube.com/watch?v=<?php echo esc_attr( $settings['video_yt_id'] ); ?>" title="" class="play-btn has-popup-video"><i class="fa fa-play"></i></a>
							</div>
							<?php endif; ?>
						</div>
						<div class="col-lg-6">
							<div class="about-text">
								<?php if ( $settings['title'] ) : ?>
								<h2 class="sub-title">
									<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
										<?php echo wp_kses_post( $settings['title'] ); ?>
									</span>
								</h2>
								<?php endif; ?>
								<?php if ( $settings['description'] ) : ?>
								<div class="description">
									<div <?php echo $this->get_render_attribute_string( 'description' ); ?>>
										<?php echo wp_kses_post( $settings['description'] ); ?>
									</div>
								</div>
								<?php endif; ?>
								<?php if ( $settings['button'] ) : ?>
								<a<?php if ( $settings['link'] ) : ?><?php if ( $settings['link']['is_external'] ) : ?> target="_blank"<?php endif; ?><?php if ( $settings['link']['nofollow'] ) : ?> rel="nofollow"<?php endif; ?> href="<?php echo esc_url( $settings['link']['url'] ); ?>"<?php endif; ?> class="lnk-default2">
									<span <?php echo $this->get_render_attribute_string( 'button' ); ?>>
										<?php echo esc_html( $settings['button'] ); ?>
									</span>
									<i class="la la-arrow-right"></i>
								</a>
								<?php endif; ?>
							</div><!--about-text end-->
						</div>
					</div>
				</div><!--about-us-section end-->
			</div>
		</section>

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() { ?>

	<#
	view.addInlineEditingAttributes( 'title', 'basic' );
	view.addInlineEditingAttributes( 'description', 'advanced' );
	view.addInlineEditingAttributes( 'button', 'basic' );
	view.addInlineEditingAttributes( 'video_title', 'basic' );
	view.addInlineEditingAttributes( 'video_button', 'basic' );
	#>

	<section class="block pb-0">
		<div class="container">
			<div class="about-us-section">
				<div class="row align-items-center">
					<div class="col-lg-6">
						<div class="abt-imgz">
							<# if ( settings.image1 ) { #>
							<img class="wow fadeInUp" data-wow-duration="1000ms" src="{{{ settings.image1.url }}}" alt="" />
							<# } #>
							<# if ( settings.image2 ) { #>
							<img class="wow fadeInRight" data-wow-duration="1000ms" data-wow-delay="400ms" src="{{{ settings.image2.url }}}" alt="" />
							<# } #>
						</div><!--abt-imgz end-->
						<# if ( settings.video == 'yes' ) { #>
						<div class="abt-txt">
							<# if ( settings.video_title ) { #>
							<h4>
								<span {{{ view.getRenderAttributeString( 'video_title' ) }}}>{{{ settings.video_title }}}</span>
							</h4>
							<# } #>
							<# if ( settings.video_button ) { #>
							<span>
								<span {{{ view.getRenderAttributeString( 'video_button' ) }}}>{{{ settings.video_button }}}</span>
							</span>
							<# } #>
							<a href="https://www.youtube.com/watch?v={{{ settings.video_yt_id }}}" title="" class="play-btn html5lightbox"><i class="fa fa-play"></i></a>
						</div>
						<# } #>
					</div>
					<div class="col-lg-6">
						<div class="about-text">
							<# if ( settings.title ) { #>
							<h2 class="sub-title">
								<span {{{ view.getRenderAttributeString( 'title' ) }}}>{{{ settings.title }}}</span>
							</h2>
							<# } #>
							<# if ( settings.description ) { #>
							<div class="description">
								<span {{{ view.getRenderAttributeString( 'title' ) }}}>{{{ settings.description }}}</span>
							</div>
							<# } #>
							<# if ( settings.button ) { #>
							<a<# if ( settings.link ) { #><# if ( settings.link.is_external ) { #> target="_blank"<# } #><# if ( settings.link.nofollow ) { #> rel="nofollow"<# } #> href="{{{ settings.link.url }}}"<# } #> class="lnk-default2">
								<span {{{ view.getRenderAttributeString( 'button' ) }}}>{{{ settings.button }}}</span>
								<i class="la la-arrow-right"></i>
							</a>
							<# } #>
						</div><!--about-text end-->
					</div>
				</div>
			</div><!--about-us-section end-->
		</div>
	</section>

	<?php }
}

Plugin::instance()->widgets_manager->register( new Minterio_About_Us_Widget() );
