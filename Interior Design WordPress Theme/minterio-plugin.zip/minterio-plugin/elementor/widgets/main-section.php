<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio Main Section Widget.
 *
 * @since 1.0
 */
class Minterio_Main_Section_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-main-section';
	}

	public function get_title() {
		return esc_html__( 'Main Section', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'content_tab',
			[
				'label' => esc_html__( 'Content', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter your description', 'minterio-plugin' ),
				'default'     => esc_html__( 'Description', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'button',
			[
				'label'       => esc_html__( 'Button (Text)', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter Button Label', 'minterio-plugin' ),
				'default'     => esc_html__( 'Button', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'link',
			[
				'label' => esc_html__( 'Button (URL)', 'minterio-plugin' ),
				'label_block' => true,
				'type' => Controls_Manager::URL,
				'show_external' => true,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'bgimages', [
				'label' => esc_html__( 'Background Image', 'minterio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri() . '/assets/images/main-banner-bg.jpg',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_tab',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image', [
				'label' => esc_html__( 'Image', 'minterio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'title', [
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'subtitle', [
				'label'       => esc_html__( 'Subtitle', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter subtitle', 'minterio-plugin' ),
				'default' => esc_html__( 'Enter subtitle', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'items',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'images_tab',
			[
				'label' => esc_html__( 'Images (Carousel)', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image', [
				'label' => esc_html__( 'Image', 'minterio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'title', [
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default' => esc_html__( 'Enter title', 'minterio-plugin' ),
			]
		);

		$this->add_control(
			'images',
			[
				'label' => esc_html__( 'Images', 'minterio-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_styling',
			[
				'label' => esc_html__( 'Content Styling', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .banner-content > h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Title Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .banner-content > h2',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label' => esc_html__( 'Description Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .banner-content > p' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'label' => esc_html__( 'Description Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .banner-content > p',
			]
		);

		$this->add_control(
			'button_color',
			[
				'label' => esc_html__( 'Button Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .lnk-default' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_bgcolor',
			[
				'label' => esc_html__( 'Button BG Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .lnk-default' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_typography',
				'label' => esc_html__( 'Button Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .lnk-default',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_styling',
			[
				'label' => esc_html__( 'Items Styling', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'items_title_color',
			[
				'label' => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .bzn-csd > h5' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'items_title_typography',
				'label' => esc_html__( 'Title Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .bzn-csd > h5',
			]
		);

		$this->add_control(
			'items_subtitle_color',
			[
				'label' => esc_html__( 'Subtitle Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .bzn-csd > span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'items_subtitle_typography',
				'label' => esc_html__( 'Subtitle Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .bzn-csd > span',
			]
		);

		$this->end_controls_section();
	}


	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'title', 'basic' );
		$this->add_inline_editing_attributes( 'description', 'basic' );
		$this->add_inline_editing_attributes( 'button', 'basic' );

		?>

		<section class="main-banner" <?php if ( $settings['bgimages'] ) : ?>style="background-image: url(<?php echo esc_url( $settings['bgimages']['url'] ); ?>);"<?php endif; ?>>
			<div class="container">
				<div class="row align-items-center">
					<div class="col-lg-6">
						<div class="banner-content">
							<?php if ( $settings['title'] ) : ?>
							<h2 class="wow fadeInUp" data-wow-duration="1000ms">
								<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
									<?php echo wp_kses_post( $settings['title'] ); ?>
								</span>
							</h2>
							<?php endif; ?>
							<?php if ( $settings['description'] ) : ?>
							<p class="wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="300ms">
								<span <?php echo $this->get_render_attribute_string( 'description' ); ?>>
									<?php echo wp_kses_post( $settings['description'] ); ?>
								</span>
							</p>
							<?php endif; ?>
							<?php if ( $settings['button'] ) : ?>
							<a<?php if ( $settings['link'] ) : ?><?php if ( $settings['link']['is_external'] ) : ?> target="_blank"<?php endif; ?><?php if ( $settings['link']['nofollow'] ) : ?> rel="nofollow"<?php endif; ?> href="<?php echo esc_url( $settings['link']['url'] ); ?>"<?php endif; ?> class="lnk-default wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="500ms">
								<span <?php echo $this->get_render_attribute_string( 'button' ); ?>>
									<?php echo esc_html( $settings['button'] ); ?>
								</span>
								<i class="la la-arrow-right"></i>
								<span class="hover"></span>
							</a>
							<?php endif; ?>
							<?php if ( $settings['items'] ) : ?>
							<ul class="banz-list wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="700ms">
								<?php foreach ( $settings['items'] as $index => $item ) :

						    	$item_title = $this->get_repeater_setting_key( 'title', 'items', $index );
						    	$this->add_inline_editing_attributes( $item_title, 'basic' );

						    	$item_subtitle = $this->get_repeater_setting_key( 'subtitle', 'items', $index );
						    	$this->add_inline_editing_attributes( $item_subtitle, 'basic' );

						        ?>
								<li>
									<div class="minterio-fzt">
										<?php if ( $item['image'] ) : $image = wp_get_attachment_image_url( $item['image']['id'], 'full' ); ?>
										<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $item['title'] ); ?>" />
										<?php endif; ?>
										<div class="bzn-csd">
											<?php if ( $item['title'] ) : ?>
											<h5>
												<span <?php echo $this->get_render_attribute_string( $item_title ); ?>>
						    						<?php echo wp_kses_post( $item['title'] ); ?>
						    					</span>
											</h5>
											<?php endif; ?>
											<?php if ( $item['subtitle'] ) : ?>
											<span>
												<span <?php echo $this->get_render_attribute_string( $item_subtitle ); ?>>
						    						<?php echo wp_kses_post( $item['subtitle'] ); ?>
						    					</span>
											</span>
											<?php endif; ?>
										</div>
									</div>
								</li>
								<?php endforeach; ?>
							</ul><!--banz-list end-->
							<?php endif; ?>

							<div class="clearfix"></div>
						</div><!--banner-content end-->
					</div>
					<div class="col-lg-6">
						<?php if ( $settings['images'] ) : ?>
						<div class="banner-slider">
							<?php foreach ( $settings['images'] as $index => $item ) : ?>
							<div class="banner-slide">
								<?php if ( $item['image'] ) : $image = wp_get_attachment_image_url( $item['image']['id'], 'minterio_618x927' ); ?>
								<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $item['title'] ); ?>" />
								<?php endif; ?>
							</div><!--banner-slide end-->
							<?php endforeach; ?>
						</div><!--banner-slider end-->
						<?php endif; ?>
					</div>
				</div>
			</div>
		</section><!--main-banner end-->

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() { ?>
		<#
		view.addInlineEditingAttributes( 'title', 'basic' );
		view.addInlineEditingAttributes( 'description', 'basic' );
		view.addInlineEditingAttributes( 'button', 'basic' );
		#>

		<section class="main-banner" <# if ( settings.bgimages ) { #>style="background-image: url({{{ settings.bgimages.url }}}"<# } #>>
			<div class="container">
				<div class="row align-items-center">
					<div class="col-lg-6">
						<div class="banner-content">
							<# if ( settings.title ) { #>
							<h2 class="wow fadeInUp" data-wow-duration="1000ms">
								<span {{{ view.getRenderAttributeString( 'title' ) }}}>{{{ settings.title }}}</span>
							</h2>
							<# } #>
							<# if ( settings.description ) { #>
							<p class="wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="300ms">
								<span {{{ view.getRenderAttributeString( 'description' ) }}}>{{{ settings.description }}}</span>
							</p>
							<# } #>
							<# if ( settings.button ) { #>
							<a<# if ( settings.link ) { #><# if ( settings.link.is_external ) { #> target="_blank"<# } #><# if ( settings.link.nofollow ) { #> rel="nofollow"<# } #> href="{{{ settings.link.url }}}"<# } #> class="lnk-default wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="500ms">
								<span {{{ view.getRenderAttributeString( 'button' ) }}}>{{{ settings.button }}}</span>
								<i class="la la-arrow-right"></i>
								<span></span>
							</a>
							<# } #>
							<# if ( settings.items ) { #>
							<ul class="banz-list wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="700ms">
								<# _.each( settings.items, function( item, index ) {
						        var item_title = view.getRepeaterSettingKey( 'title', 'items', index );
						    	view.addInlineEditingAttributes( item_title, 'basic' );

						    	var item_subtitle = view.getRepeaterSettingKey( 'subtitle', 'items', index );
						    	view.addInlineEditingAttributes( item_subtitle, 'basic' );
						        #>
								<li>
									<div class="minterio-fzt">
										<# if ( item.image ) { #>
										<img src="{{{ item.image.url }}}" alt="{{{ item.title }}}" />
										<# } #>
										<div class="bzn-csd">
											<# if ( item.title ) { #>
											<h5>
												<span {{{ view.getRenderAttributeString( item_title ) }}}>{{{ item.title }}}</span>
											</h5>
											<# } #>
											<# if ( item.subtitle ) { #>
											<span>
												<span {{{ view.getRenderAttributeString( item_subtitle ) }}}>{{{ item.subtitle }}}</span>
											</span>
											<# } #>
										</div>
									</div>
								</li>
								<# }); #>
							</ul><!--banz-list end-->
							<# } #>

							<div class="clearfix"></div>
						</div><!--banner-content end-->
					</div>
					<div class="col-lg-6">
						<# if ( settings.images ) { #>
						<div class="banner-slider">
							<# _.each( settings.images, function( item, index ) { #>
							<div class="banner-slide">
								<# if ( item.image ) { #>
								<img src="{{{ item.image.url }}}" alt="{{{ item.title }}}" />
								<# } #>
							</div><!--banner-slide end-->
							<# }); #>
						</div><!--banner-slider end-->
						<# } #>
					</div>
				</div>
			</div>
		</section><!--main-banner end-->

	<?php }
}

Plugin::instance()->widgets_manager->register( new Minterio_Main_Section_Widget() );
