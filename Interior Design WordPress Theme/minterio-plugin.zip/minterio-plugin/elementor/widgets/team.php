<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio Team Widget.
 *
 * @since 1.0
 */

class Minterio_Team_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-team';
	}

	public function get_title() {
		return esc_html__( 'Team', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'heading_tab',
			[
				'label' => esc_html__( 'Heading', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'title_layout',
			[
				'label'       => esc_html__( 'Layout', 'minterio-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'style-1',
				'options' => [
					'style-1'  => __( 'Style 1', 'minterio-plugin' ),
					'style-2' => __( 'Style 2', 'minterio-plugin' ),
				],
			]
		);

		$this->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter description', 'minterio-plugin' ),
				'default'     => esc_html__( 'Description', 'minterio-plugin' ),
				'condition' => [
		            'title_layout' => 'style-2'
		        ],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_tab',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'heading',
			[
				'label' => esc_html__( 'Heading (Left)', 'minterio-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'minterio-plugin' ),
				'label_off' => __( 'Hide', 'minterio-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'heading_num',
			[
				'label'       => esc_html__( 'Num', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter num', 'minterio-plugin' ),
				'default'     => esc_html__( '6', 'minterio-plugin' ),
				'condition' => [
		            'heading' => 'yes'
		        ],
			]
		);

		$this->add_control(
			'heading_text',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
				'condition' => [
		            'heading' => 'yes'
		        ],
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image', [
				'label' => esc_html__( 'Image', 'minterio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'name', [
				'label'       => esc_html__( 'Name', 'minterio-plugin' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter name', 'minterio-plugin' ),
				'default' => esc_html__( 'Enter name', 'minterio-plugin' ),
			]
		);

		$repeater->add_control(
			'role', [
				'label'       => esc_html__( 'Role', 'minterio-plugin' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter role', 'minterio-plugin' ),
				'default' => esc_html__( 'Enter role', 'minterio-plugin' ),
			]
		);

		$this->add_control(
			'items',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ name }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'heading_styling',
			[
				'label' => esc_html__( 'Heading', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .sub-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .sub-title',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_styling',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'heading_num_color',
			[
				'label' => esc_html__( 'Heading Num', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .team-head > h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'heading_num_typography',
				'label' => esc_html__( 'Heading Num Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .team-head > h2',
			]
		);

		$this->add_control(
			'heading_title_color',
			[
				'label' => esc_html__( 'Heading Title', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .team-head > h3' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'heading_title_typography',
				'label' => esc_html__( 'Heading Title Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .team-head > h3',
			]
		);

		$this->add_control(
			'item_name_color',
			[
				'label' => esc_html__( 'Name Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .figcaption > h3' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_name_typography',
				'label' => esc_html__( 'Name Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .figcaption > h3',
			]
		);

		$this->add_control(
			'item_role_color',
			[
				'label' => esc_html__( 'Role Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .figcaption > span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_role_typography',
				'label' => esc_html__( 'Role Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .figcaption > span',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'title', 'basic' );
		$this->add_inline_editing_attributes( 'description', 'basic' );
		$this->add_inline_editing_attributes( 'heading_num', 'basic' );
		$this->add_inline_editing_attributes( 'heading_text', 'basic' );

		?>

		<section class="block pb-0">
			<div class="container">
				<?php if ( $settings['title_layout'] == 'style-2' ) : ?>
				<div class="section-title style2 align-items-center">
				<?php endif; ?>
				<?php if ( $settings['title'] ) : ?>
				<h3 class="sub-title">
					<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
						<?php echo wp_kses_post( $settings['title'] ); ?>
					</span>
				</h3>
				<?php endif; ?>
				<?php if ( $settings['title_layout'] == 'style-2' ) : ?>
					<?php if ( $settings['description'] ) : ?>
					<p class="mw-50">
						<span <?php echo $this->get_render_attribute_string( 'description' ); ?>>
							<?php echo wp_kses_post( $settings['description'] ); ?>
						</span>
					</p>
					<?php endif; ?>
					<div class="clearfix"></div>
				</div>
				<?php endif; ?>
				<div class="team-section">
					<div class="row">
						<?php if ( $settings['heading'] == 'yes' ) : ?>
						<div class="col-lg-5">
							<div class="team-head">
								<?php if ( $settings['heading_num'] ) : ?>
								<h2>
									<span <?php echo $this->get_render_attribute_string( 'heading_num' ); ?>>
										<?php echo wp_kses_post( $settings['heading_num'] ); ?>
									</span>
								</h2>
								<?php endif; ?>
								<?php if ( $settings['heading_text'] ) : ?>
								<h3>
									<span <?php echo $this->get_render_attribute_string( 'heading_text' ); ?>>
										<?php echo wp_kses_post( $settings['heading_text'] ); ?>
									</span>
								</h3>
								<?php endif; ?>
							</div><!--team-head end-->
						</div>
						<?php endif; ?>
						<div class="<?php if ( $settings['heading'] == 'yes' ) : ?>col-lg-7<?php else : ?>col-lg-12<?php endif; ?>">
							<?php if ( $settings['items'] ) : ?>
							<div class="row">
								<?php foreach ( $settings['items'] as $index => $item ) :
									$item_name = $this->get_repeater_setting_key( 'name', 'items', $index );
							    	$this->add_inline_editing_attributes( $item_name, 'basic' );

							    	$item_role = $this->get_repeater_setting_key( 'role', 'items', $index );
							    	$this->add_inline_editing_attributes( $item_role, 'basic' );
								?>
								<div class="col-lg-4 col-md-6 col-sm-6 col-12">
									<div class="team">
										<?php if ( $item['image'] ) : $image = wp_get_attachment_image_url( $item['image']['id'], 'minterio_900x900' ); ?>
										<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>" />
										<?php endif; ?>
										<?php if ( $item['name'] || $item['role'] ) : ?>
										<div class="figcaption">
											<?php if ( $item['name'] ) : ?>
											<h3>
												<span <?php echo $this->get_render_attribute_string( $item_name ); ?>>
													<?php echo wp_kses_post( $item['name'] ); ?>
												</span>
											</h3>
											<?php endif; ?>
											<?php if ( $item['role'] ) : ?>
											<span>
												<span <?php echo $this->get_render_attribute_string( $item_role ); ?>>
													<?php echo wp_kses_post( $item['role'] ); ?>
												</span>
											</span>
											<?php endif; ?>
										</div>
										<?php endif; ?>
									</div><!--team end-->
								</div>
								<?php endforeach; ?>
							</div>
							<?php endif; ?>
						</div>
					</div>
				</div><!--team-section end-->
			</div>
		</section>

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() { ?>

		<#
		view.addInlineEditingAttributes( 'title', 'basic' );
		view.addInlineEditingAttributes( 'description', 'basic' );
		view.addInlineEditingAttributes( 'heading_num', 'basic' );
		view.addInlineEditingAttributes( 'heading_text', 'basic' );
		#>

		<section class="block pb-0">
			<div class="container">
				<# if ( settings.title_layout == 'style-2' ) { #>
				<div class="section-title style2 align-items-center">
				<# } #>
				<# if ( settings.title ) { #>
				<h3 class="sub-title">
					<span {{{ view.getRenderAttributeString( 'title' ) }}}>
        				{{{ settings.title }}}
        			</span>
				</h3>
				<# } #>
				<# if ( settings.title_layout == 'style-2' ) { #>
					<# if ( settings.description ) { #>
					<p class="mw-50">
						<span {{{ view.getRenderAttributeString( 'description' ) }}}>
	        				{{{ settings.description }}}
	        			</span>
					</p>
					<# } #>
					<div class="clearfix"></div>
				</div>
				<# } #>
				<div class="team-section">
					<div class="row">
						<# if ( settings.heading == 'yes' ) { #>
						<div class="col-lg-5">
							<div class="team-head">
								<# if ( settings.heading_num ) { #>
								<h2>
									<span {{{ view.getRenderAttributeString( 'heading_num' ) }}}>
				        				{{{ settings.heading_num }}}
				        			</span>
								</h2>
								<# } #>
								<# if ( settings.heading_text ) { #>
								<h3>
									<span {{{ view.getRenderAttributeString( 'heading_text' ) }}}>
				        				{{{ settings.heading_text }}}
				        			</span>
								</h3>
								<# } #>
							</div><!--team-head end-->
						</div>
						<# } #>
						<div class="<# if ( settings.heading == 'yes' ) { #>col-lg-7<# } else { #>col-lg-12<# } #>">
							<# if ( settings.items ) { #>
							<div class="row">
								<# _.each( settings.items, function( item, index ) {
									var item_role = view.getRepeaterSettingKey( 'role', 'items', index );
								    view.addInlineEditingAttributes( item_role, 'basic' );

								    var item_name = view.getRepeaterSettingKey( 'name', 'items', index );
								    view.addInlineEditingAttributes( item_name, 'basic' );
								#>
								<div class="col-lg-4 col-md-6 col-sm-6 col-12">
									<div class="team">
										<# if ( item.image ) { #>
										<img src="{{{ item.image.url }}}" alt="{{{ item.name }}}" />
										<# } #>
										<# if ( item.name || item.role ) { #>
										<div class="figcaption">
											<# if ( item.name ) { #>
											<h3>
												<span {{{ view.getRenderAttributeString( item_name ) }}}>
													{{{ item.name }}}
												</span>
											</h3>
											<# } #>
											<# if ( item.role ) { #>
											<span>
												<span {{{ view.getRenderAttributeString( item_role ) }}}>
													{{{ item.role }}}
												</span>
											</span>
											<# } #>
										</div>
										<# } #>
									</div><!--team end-->
								</div>
								<# }); #>
							</div>
							<# } #>
						</div>
					</div>
				</div><!--team-section end-->
			</div>
		</section>

	<?php }
}

Plugin::instance()->widgets_manager->register( new Minterio_Team_Widget() );
