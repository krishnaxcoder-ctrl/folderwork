<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio About Description Widget.
 *
 * @since 1.0
 */
class Minterio_About_Description_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-about-description';
	}

	public function get_title() {
		return esc_html__( 'About Description', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'content_tab',
			[
				'label' => esc_html__( 'Content', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'minterio-plugin' ),
				'type'        => Controls_Manager::WYSIWYG,
				'placeholder' => esc_html__( 'Enter description', 'minterio-plugin' ),
				'default'     => esc_html__( 'Description', 'minterio-plugin' ),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_styling',
			[
				'label'     => esc_html__( 'Content Styling', 'minterio-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .our-history .sub-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'label'     => esc_html__( 'Title Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .our-history .sub-title',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Description Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .our-history .description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'label'     => esc_html__( 'Description Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .our-history .description',
			]
		);

		$this->end_controls_section();
	}


	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'title', 'basic' );
		$this->add_inline_editing_attributes( 'description', 'advanced' );

		?>

		<section class="block2">
			<div class="container">
				<div class="our-history">
					<?php if ( $settings['title'] ) : ?>
					<h3 class="sub-title">
						<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
							<?php echo wp_kses_post( $settings['title'] ); ?>
						</span>
					</h3>
					<?php endif; ?>
					<?php if ( $settings['description'] ) : ?>
					<div class="description">
						<div <?php echo $this->get_render_attribute_string( 'description' ); ?>>
							<?php echo wp_kses_post( $settings['description'] ); ?>
						</div>
					</div>
					<?php endif; ?>
				</div><!--our-history end-->
			</div>
		</section>

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() { ?>

	<#
	view.addInlineEditingAttributes( 'title', 'basic' );
	view.addInlineEditingAttributes( 'description', 'advanced' );
	#>

	<section class="block2">
		<div class="container">
			<div class="our-history">
				<# if ( settings.title ) { #>
				<h3 class="sub-title">
					<span {{{ view.getRenderAttributeString( 'title' ) }}}>{{{ settings.title }}}</span>
				</h3>
				<# } #>
				<# if ( settings.description ) { #>
				<div class="description">
					<div {{{ view.getRenderAttributeString( 'description' ) }}}>{{{ settings.description }}}</div>
				</div>
				<# } #>
			</div><!--our-history end-->
		</div>
	</section>

	<?php }
}

Plugin::instance()->widgets_manager->register( new Minterio_About_Description_Widget() );
