<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio Footer Menu Widget.
 *
 * @since 1.0
 */

class Minterio_Footer_Menu_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-footer-menu';
	}

	public function get_title() {
		return esc_html__( 'Footer Menu', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'content_tab',
			[
				'label' => esc_html__( 'Content', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'menu_tab',
			[
				'label' => esc_html__( 'Menu', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'menu',
			[
				'label' => esc_html__( 'Select Menu', 'minterio-plugin' ),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->nav_menu_list(),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_styling',
			[
				'label' => esc_html__( 'Content Styling', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .widget-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Title Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .widget-title',
			]
		);

		$this->add_control(
			'menu_item_color',
			[
				'label' => esc_html__( 'Menu Item Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ft-links li a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'menu_item_hover_color',
			[
				'label' => esc_html__( 'Menu Item Hover Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .ft-links li a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'menu_item_typography',
				'label' => esc_html__( 'Menu Item Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .ft-links li',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render Contact Form List.
	 *
	 * @since 1.0
	 */
	protected function nav_menu_list() {
		$menus = wp_get_nav_menus();
		$items = array();
		$i = 0;

		foreach ( $menus as $menu ) {
			if ( $i == 0 ) {
				$default = $menu->slug;
				$i ++;
			}
			$items[ $menu->slug ] = $menu->name;
		}

		return $items;
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'title', 'basic' );

		?>

		<div class="widget widget-category text-right">
			<?php if ( $settings['title'] ) : ?>
			<h3 class="widget-title">
				<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
					<?php echo wp_kses_post( $settings['title'] ); ?>
				</span>
			</h3>
			<?php endif; ?>
			<nav class="ft-links">
				<?php minterio_get_topmenu_horizontal( $settings['menu'] ); ?>
			</nav><!--ft-links end-->
		</div><!--widget-contact end-->

		<?php
	}
}

Plugin::instance()->widgets_manager->register( new Minterio_Footer_Menu_Widget() );
