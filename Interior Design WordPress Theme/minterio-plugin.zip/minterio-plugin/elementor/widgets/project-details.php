<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio Project Details Widget.
 *
 * @since 1.0
 */
class Minterio_Project_Details_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-project-details';
	}

	public function get_title() {
		return esc_html__( 'Project Details', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'media_tab',
			[
				'label' => esc_html__( 'Media', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'image1',
			[
				'label'       => esc_html__( 'Image #1', 'minterio-plugin' ),
				'type'        => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'image2',
			[
				'label'       => esc_html__( 'Image #2', 'minterio-plugin' ),
				'type'        => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'image3',
			[
				'label'       => esc_html__( 'Image #3', 'minterio-plugin' ),
				'type'        => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'video',
			[
				'label' => esc_html__( 'Show Button', 'minterio-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'minterio-plugin' ),
				'label_off' => __( 'Hide', 'minterio-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'video_select',
			[
				'label'       => esc_html__( 'Source', 'minterio-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'show_video',
				'options' => [
					'show_video'  => __( 'Video', 'minterio-plugin' ),
					'show_link' => __( 'URL Link', 'minterio-plugin' ),
				],
				'condition' => [
		            'video' => 'yes',
		        ],
			]
		);

		$this->add_control(
			'video_yt_id',
			[
				'label'       => esc_html__( 'Youtube (Video ID)', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter Video ID', 'minterio-plugin' ),
				'default'     => esc_html__( 'pNxqh-JCMpw', 'minterio-plugin' ),
				'condition' => [
		            'video' => 'yes',
					'video_select' => 'show_video',
		        ],
			]
		);
		
		$this->add_control(
			'video_lnk',
			[
				'label'       => esc_html__( 'URL', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter URL', 'minterio-plugin' ),
				'condition' => [
		            'video' => 'yes',
					'video_select' => 'show_link',
		        ],
			]
		);

		$this->add_control(
			'video_title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
				'condition' => [
		            'video' => 'yes',
		        ],
			]
		);

		$this->add_control(
			'video_button',
			[
				'label'       => esc_html__( 'Button', 'minterio-plugin' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter label', 'minterio-plugin' ),
				'default'     => esc_html__( 'Play video', 'minterio-plugin' ),
				'condition' => [
		            'video' => 'yes',
		        ],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_tab',
			[
				'label' => esc_html__( 'Content', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
			]
		);

		$this->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'minterio-plugin' ),
				'type'        => Controls_Manager::WYSIWYG,
				'placeholder' => esc_html__( 'Enter description', 'minterio-plugin' ),
				'default'     => esc_html__( 'Description', 'minterio-plugin' ),
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'title', [
				'label_block' => true,
				'label' => esc_html__( 'Label', 'minterio-plugin' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Enter label', 'minterio-plugin' ),
				'placeholder' => esc_html__( 'Label', 'minterio-plugin' ),
			]
		);

		$repeater->add_control(
			'text', [
				'label_block' => true,
				'label' => esc_html__( 'Value', 'minterio-plugin' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Enter value', 'minterio-plugin' ),
				'placeholder' => esc_html__( 'Value', 'minterio-plugin' ),
			]
		);

		$this->add_control(
			'items',
			[
				'label' => esc_html__( 'Details', 'minterio-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
			]
		);

		$this->add_control(
			'social_share',
			[
				'label' => esc_html__( 'Social Share', 'minterio-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'minterio-plugin' ),
				'label_off' => __( 'Hide', 'minterio-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'navigation',
			[
				'label' => esc_html__( 'Navigation', 'minterio-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'minterio-plugin' ),
				'label_off' => __( 'Hide', 'minterio-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_styling',
			[
				'label'     => esc_html__( 'Content', 'minterio-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .portfolio-details-info > h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'label'     => esc_html__( 'Title Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .portfolio-details-info > h2',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Description Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .portfolio-details-info .description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'label'     => esc_html__( 'Description Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .portfolio-details-info .description',
			]
		);

		$this->add_control(
			'video_title_color',
			[
				'label'     => esc_html__( 'Video Title Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .abt-txt > h4' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'video_title_typography',
				'label'     => esc_html__( 'Video Title Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .abt-txt > h4',
			]
		);

		$this->add_control(
			'video_button_color',
			[
				'label'     => esc_html__( 'Video Button Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .abt-txt > span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'video_button_typography',
				'label'     => esc_html__( 'Video Button Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .abt-txt > span',
			]
		);

		$this->add_control(
			'item_label_color',
			[
				'label'     => esc_html__( 'Details Label Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .pz-list li h4' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'item_label_typography',
				'label'     => esc_html__( 'Label Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .pz-list li h4',
			]
		);

		$this->add_control(
			'item_value_color',
			[
				'label'     => esc_html__( 'Value Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .pz-list li > span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'item_value_typography',
				'label'     => esc_html__( 'Value Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .pz-list li > span',
			]
		);

		$this->end_controls_section();
	}


	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'title', 'basic' );
		$this->add_inline_editing_attributes( 'description', 'advanced' );
		$this->add_inline_editing_attributes( 'video_title', 'basic' );
		$this->add_inline_editing_attributes( 'video_button', 'basic' );

		?>

		<section class="page-content pt-0">
			<div class="container">
				<div class="portfolio-details-page">
					<div class="row">
						<div class="col-lg-6">
							<?php if ( $settings['image1'] || $settings['image2'] || $settings['video'] == 'yes' ) : ?>
							<div class="abt-zimg">
								<?php if ( $settings['image1'] || $settings['image2'] ) : ?>
								<div class="abt-imgz">
									<?php if ( $settings['image1'] ) : $image = wp_get_attachment_image_url( $settings['image1']['id'], 'minterio_900xAuto' ); ?>
									<img src="<?php echo esc_url( $image ); ?>" alt="" />
									<?php endif; ?>
									<?php if ( $settings['image2'] ) : $image = wp_get_attachment_image_url( $settings['image2']['id'], 'minterio_900xAuto' ); ?>
									<img src="<?php echo esc_url( $image ); ?>" alt="" />
									<?php endif; ?>
								</div><!--abt-imgz end-->
								<?php endif; ?>
								<?php if ( $settings['video'] == 'yes' ) : ?>
								<div class="abt-txt">
									<?php if ( $settings['video_title'] ) : ?>
									<h4>
										<span <?php echo $this->get_render_attribute_string( 'video_title' ); ?>>
											<?php echo wp_kses_post( $settings['video_title'] ); ?>
										</span>
									</h4>
									<?php endif; ?>
									<?php if ( $settings['video_button'] ) : ?>
									<span>
										<span <?php echo $this->get_render_attribute_string( 'video_button' ); ?>>
											<?php echo wp_kses_post( $settings['video_button'] ); ?>
										</span>
									</span>
									<?php endif; ?>
									<?php if ( $settings['video_select'] == 'show_video' ) : ?>
									<a href="https://www.youtube.com/watch?v=<?php echo esc_attr( $settings['video_yt_id'] ); ?>" title="" class="play-btn has-popup-video"><i class="fa fa-play"></i></a>
									<?php endif; ?>
									<?php if ( $settings['video_select'] == 'show_link' ) : ?>
									<a href="<?php echo esc_attr( $settings['video_lnk'] ); ?>" target="blank" title="" class="play-btn"><i class="fa fa-play"></i></a>
									<?php endif; ?>
								</div>
								<?php endif; ?>
							</div><!--abt-zimg end-->
							<?php endif; ?>
							<?php if ( $settings['image3'] ) : $image = wp_get_attachment_image_url( $settings['image3']['id'], 'minterio_900xAuto' ); ?>
							<div class="azt-img">
								<img src="<?php echo esc_url( $image ); ?>" alt="" class="w-100" />
							</div>
							<?php endif; ?>
						</div>
						<div class="col-lg-6">
							<div class="portfolio-details-info">
								<?php if ( $settings['title'] ) : ?>
								<h2>
									<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
										<?php echo wp_kses_post( $settings['title'] ); ?>
									</span>
								</h2>
								<?php endif; ?>
								<?php if ( $settings['description'] ) : ?>
								<div class="description">
									<div <?php echo $this->get_render_attribute_string( 'description' ); ?>>
										<?php echo wp_kses_post( $settings['description'] ); ?>
									</div>
								</div>
								<?php endif; ?>
								<?php if ( $settings['items'] ) : ?>
								<ul class="pz-list">
									<?php foreach ( $settings['items'] as $index => $item ) :
								    	$item_title = $this->get_repeater_setting_key( 'title', 'items', $index );
								    	$this->add_inline_editing_attributes( $item_title, 'basic' );

								    	$item_text = $this->get_repeater_setting_key( 'text', 'items', $index );
								    	$this->add_inline_editing_attributes( $item_text, 'basic' );
									?>
									<li>
										<?php if ( $item['title'] ) : ?>
										<h4>
											<span <?php echo $this->get_render_attribute_string( $item_title ); ?>>
												<?php echo wp_kses_post( $item['title'] ); ?>
											</span>
										</h4>
										<?php endif; ?>
										<?php if ( $item['text'] ) : ?>
										<span>
											<span <?php echo $this->get_render_attribute_string( $item_text ); ?>>
												<?php echo wp_kses_post( $item['text'] ); ?>
											</span>
										</span>
										<?php endif; ?>
									</li>
									<?php endforeach; ?>
								</ul>
								<?php endif; ?>
								<?php if ( $settings['social_share'] == 'yes' ) : minterio_post_social(); endif; ?>
								<?php if ( $settings['navigation'] == 'yes' ) : minterio_post_navigation(); endif; ?>
							</div><!--catalog-product-info end-->
						</div>
					</div>
				</div><!--catalog-product-page end-->
			</div>
		</section><!--page-content end-->

		<?php
	}
}

Plugin::instance()->widgets_manager->register( new Minterio_Project_Details_Widget() );
