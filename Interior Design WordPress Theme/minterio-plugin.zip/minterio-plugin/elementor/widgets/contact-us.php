<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio Contact Us Widget.
 *
 * @since 1.0
 */

class Minterio_Contact_Us_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-contact-us';
	}

	public function get_title() {
		return esc_html__( 'Contact Us', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'content_tab',
			[
				'label' => esc_html__( 'Heading', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description (Before)', 'minterio-plugin' ),
				'type'        => Controls_Manager::WYSIWYG,
				'placeholder' => esc_html__( 'Enter description', 'minterio-plugin' ),
				'default'     => '',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_tab',
			[
				'label' => esc_html__( 'Contact Items', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'icon', [
				'label'       => esc_html__( 'Icon', 'myour-plugin' ),
				'type'        => Controls_Manager::ICONS,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'name', [
				'label'       => esc_html__( 'Name', 'minterio-plugin' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter name', 'minterio-plugin' ),
				'default' => esc_html__( 'Name', 'minterio-plugin' ),
			]
		);

		$repeater->add_control(
			'text', [
				'label'       => esc_html__( 'Text', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter text', 'minterio-plugin' ),
				'default' => esc_html__( 'Text', 'minterio-plugin' ),
			]
		);

		$this->add_control(
			'items',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ name }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'form_tab',
			[
				'label' => esc_html__( 'Form', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'contact_form',
			[
				'label' => esc_html__( 'Select CF7 Form', 'minterio-plugin' ),
				'type' => Controls_Manager::SELECT,
				'default' => 1,
				'options' => $this->contact_form_list(),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'social_tab',
			[
				'label' => esc_html__( 'Social', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'social',
			[
				'label' => esc_html__( 'Social', 'minterio-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'minterio-plugin' ),
				'label_off' => __( 'Hide', 'minterio-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'social_before',
			[
				'label'       => esc_html__( 'Social Text (Before)', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter text', 'minterio-plugin' ),
				'default'     => esc_html__( 'Subscribe to our social networks :', 'minterio-plugin' ),
				'condition' => [
            		'social' => 'yes'
        		],
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'icon', [
				'label'       => esc_html__( 'Icon', 'myour-plugin' ),
				'type'        => Controls_Manager::ICONS,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'name', [
				'label'       => esc_html__( 'Name', 'minterio-plugin' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter name', 'minterio-plugin' ),
				'default' => esc_html__( 'Name', 'minterio-plugin' ),
			]
		);

		$repeater->add_control(
			'url', [
				'label'       => esc_html__( 'URL', 'minterio-plugin' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter url', 'minterio-plugin' ),
				'default' => esc_html__( 'https://', 'minterio-plugin' ),
			]
		);

		$this->add_control(
			'social_items',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ name }}}',
				'condition' => [
            		'social' => 'yes'
        		],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_styling',
			[
				'label' => esc_html__( 'Content', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .sub-title.white' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Title Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .sub-title.white',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label' => esc_html__( 'Description Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .contact-head p' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'label' => esc_html__( 'Description Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .contact-head p',
			]
		);

		$this->add_control(
			'item_icon_color',
			[
				'label' => esc_html__( 'Item Icon Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .cl-list li > span i' => 'color: {{VALUE}};',
					'{{WRAPPER}} .cl-list li > span svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'item_label_color',
			[
				'label' => esc_html__( 'Item Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .cl-list li > p' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_label_typography',
				'label' => esc_html__( 'Item Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .cl-list li > p',
			]
		);

		$this->add_control(
			'social_text_color',
			[
				'label' => esc_html__( 'Social Text Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .contact-social > span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'social_text_typography',
				'label' => esc_html__( 'Social Text Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .contact-social > span',
			]
		);

		$this->add_control(
			'social_link_color',
			[
				'label' => esc_html__( 'Social Link Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .social-links.without-bg li a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .social-links.without-bg li a svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'social_link_hover_color',
			[
				'label' => esc_html__( 'Social Link Hover Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .social-links.without-bg li a:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .social-links.without-bg li a:hover svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render Contact Form List.
	 *
	 * @since 1.0
	 */
	protected function contact_form_list() {
		$cf7_posts = get_posts( 'post_type="wpcf7_contact_form"&numberposts=-1' );

		$cf7_forms = array();

		if ( $cf7_posts ) {
			foreach ( $cf7_posts as $cf7_form ) {
				$cf7_forms[ $cf7_form->ID ] = $cf7_form->post_title;
			}
		} else {
			$cf7_forms[ esc_html__( 'No contact forms found', 'minterio-plugin' ) ] = 0;
		}

		return $cf7_forms;
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'title', 'basic' );
		$this->add_inline_editing_attributes( 'description', 'advanced' );
		$this->add_inline_editing_attributes( 'social_before', 'basic' );

		?>

		<section class="page-content">
			<div class="container">
				<div class="contact-page">
					<?php if ( $settings['description'] ) : ?>
					<div class="contact-head">
						<div <?php echo $this->get_render_attribute_string( 'description' ); ?>>
							<?php echo wp_kses_post( $settings['description'] ); ?>
						</div>
					</div><!--contact-head end-->
					<?php endif; ?>
					<div class="contact-main">
						<div class="row">
							<div class="col-lg-4">
								<div class="contact_info">
									<?php if ( $settings['title'] ) : ?>
									<h3 class="sub-title white">
										<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
											<?php echo wp_kses_post( $settings['title'] ); ?>
										</span>
									</h3>
									<?php endif; ?>
									<?php if ( $settings['items'] ) : ?>
									<ul class="cl-list">
										<?php foreach ( $settings['items'] as $index => $item ) :
									    	$item_text = $this->get_repeater_setting_key( 'text', 'items', $index );
									    	$this->add_inline_editing_attributes( $item_text, 'basic' );
									    ?>
										<li>
											<span class="ci-icon">
												<?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
											</span>
											<p>
												<span <?php echo $this->get_render_attribute_string( $item_text ); ?>>
													<?php echo wp_kses_post( $item['text'] ); ?>
												</span>
											</p>
										</li>
										<?php endforeach; ?>
									</ul>
									<?php endif; ?>
								</div>
							</div>
							<div class="col-lg-8">
								<?php if ( $settings['contact_form'] ) : ?>
								<div class="contact-main-form">
									<?php echo do_shortcode( '[contact-form-7 id="'. esc_attr( $settings['contact_form'] ) .'"]' ); ?>
								</div><!--contact-main-form end-->
								<?php endif; ?>
							</div>
						</div>
					</div><!--contact-main end-->
					<?php if ( $settings['social'] == 'yes' ) : ?>
					<div class="contact-social">
						<?php if ( $settings['social_before'] ) : ?>
						<span>
							<span <?php echo $this->get_render_attribute_string( 'social_before' ); ?>>
								<?php echo wp_kses_post( $settings['social_before'] ); ?>
							</span>
						</span>
						<?php endif; ?>
						<?php if ( $settings['social_items'] ) : ?>
						<ul class="social-links without-bg">
							<?php foreach ( $settings['social_items'] as $index => $item ) : ?>
							<li>
								<a href="<?php echo esc_url( $item['url'] ); ?>" target="_blank">
									<?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
								</a>
							</li>
							<?php endforeach; ?>
						</ul>
						<?php endif; ?>
					</div><!--contact-social end-->
					<?php endif; ?>
				</div><!--contact-page end-->
			</div>
		</section><!--page-content end-->

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() { ?>

		<#
		view.addInlineEditingAttributes( 'title', 'basic' );
		view.addInlineEditingAttributes( 'description', 'advanced' );
		view.addInlineEditingAttributes( 'social_before', 'basic' );
		#>

		<section class="page-content">
			<div class="container">
				<div class="contact-page">
					<# if( settings.description ) { #>
					<div class="contact-head">
						<div {{{ view.getRenderAttributeString( 'description' ) }}}>{{{ settings.description }}}</div>
					</div><!--contact-head end-->
					<# } #>
					<div class="contact-main">
						<div class="row">
							<div class="col-lg-4">
								<div class="contact_info">
									<# if( settings.title ) { #>
									<h3 class="sub-title white">
										<span {{{ view.getRenderAttributeString( 'title' ) }}}>{{{ settings.title }}}</span>
									</h3>
									<# } #>
									<# if( settings.items ) { #>
									<ul class="cl-list">
										<# _.each( settings.items, function( item, index ) {
											var item_text = view.getRepeaterSettingKey( 'text', 'items', index );
										    view.addInlineEditingAttributes( item_text, 'basic' );

											var iconHTML = elementor.helpers.renderIcon( view, item.icon, { 'aria-hidden': true }, 'i' , 'object' );
										#>
										<li>
											<span class="ci-icon">
												{{{ iconHTML.value }}}
											</span>
											<p>
												<span {{{ view.getRenderAttributeString( item_text ) }}}>
													{{{ item.text }}}
												</span>
											</p>
										</li>
										<# }); #>
									</ul>
									<# } #>
								</div>
							</div>
							<div class="col-lg-8">
								<# if ( settings.contact_form ) { #>
								<div class="contact-main-form">
									[contact-form-7 id="{{{ settings.contact_form }}}"]
								</div><!--contact-main-form end-->
								<# } #>
							</div>
						</div>
					</div><!--contact-main end-->
					<# if( settings.social == 'yes' ) { #>
					<div class="contact-social">
						<# if( settings.social_before ) { #>
						<span>
							<span {{{ view.getRenderAttributeString( 'social_before' ) }}}>{{{ settings.social_before }}}</span>
						</span>
						<# } #>
						<# if( settings.social_items ) { #>
						<ul class="social-links without-bg">
							<# _.each( settings.social_items, function( item, index ) {
								var iconHTML = elementor.helpers.renderIcon( view, item.icon, { 'aria-hidden': true }, 'i' , 'object' );
							#>
							<li>
								<a href="{{{ item.url }}}" target="_blank">
									{{{ iconHTML.value }}}
								</a>
							</li>
							<# }); #>
						</ul>
						<# } #>
					</div><!--contact-social end-->
					<# } #>
				</div><!--contact-page end-->
			</div>
		</section><!--page-content end-->

	<?php }
}

Plugin::instance()->widgets_manager->register( new Minterio_Contact_Us_Widget() );
