<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio Services Widget.
 *
 * @since 1.0
 */

class Minterio_Services_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-services';
	}

	public function get_title() {
		return esc_html__( 'Services', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'content_tab',
			[
				'label' => esc_html__( 'Content', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'minterio-plugin' ),
				'type'        => Controls_Manager::WYSIWYG,
				'placeholder' => esc_html__( 'Enter your description', 'minterio-plugin' ),
				'default'     => esc_html__( 'Description', 'minterio-plugin' ),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'team_tab',
			[
				'label' => esc_html__( 'Team', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image', [
				'label' => esc_html__( 'Image', 'minterio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'name', [
				'label'       => esc_html__( 'Name', 'minterio-plugin' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter name', 'minterio-plugin' ),
				'default' => esc_html__( 'Name', 'minterio-plugin' ),
			]
		);

		$repeater->add_control(
			'role', [
				'label'       => esc_html__( 'Role', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter role', 'minterio-plugin' ),
				'default' => esc_html__( 'Role', 'minterio-plugin' ),
			]
		);

		$repeater->add_control(
			'description', [
				'label'       => esc_html__( 'Description', 'minterio-plugin' ),
				'type'        => Controls_Manager::WYSIWYG,
				'placeholder' => esc_html__( 'Enter description', 'minterio-plugin' ),
				'default' => esc_html__( 'Description', 'minterio-plugin' ),
			]
		);

		$this->add_control(
			'team_items',
			[
				'label' => esc_html__( 'Team Items', 'minterio-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ name }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'services_tab',
			[
				'label' => esc_html__( 'Services', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image', [
				'label' => esc_html__( 'Image', 'minterio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'title', [
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default' => esc_html__( 'Enter title', 'minterio-plugin' ),
			]
		);

		$repeater->add_control(
			'description', [
				'label'       => esc_html__( 'Description', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter text', 'minterio-plugin' ),
				'default' => esc_html__( 'Enter text', 'minterio-plugin' ),
			]
		);

		$this->add_control(
			'serv_items',
			[
				'label' => esc_html__( 'Services Items', 'minterio-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_styling',
			[
				'label' => esc_html__( 'Heading', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .section-title .sub-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Title Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .section-title .sub-title',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label' => esc_html__( 'Description Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .section-title > .description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'label' => esc_html__( 'Description Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .section-title > .description',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'team_styling',
			[
				'label' => esc_html__( 'Team', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'team_name_color',
			[
				'label' => esc_html__( 'Name Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .post-info > h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'team_name_typography',
				'label' => esc_html__( 'Name Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .post-info > h2',
			]
		);

		$this->add_control(
			'team_role_color',
			[
				'label' => esc_html__( 'Role Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .post-info > span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'team_role_typography',
				'label' => esc_html__( 'Role Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .post-info > span',
			]
		);

		$this->add_control(
			'team_description_color',
			[
				'label' => esc_html__( 'Description Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .post-info .description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'team_description_typography',
				'label' => esc_html__( 'Description Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .post-info .description',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'services_styling',
			[
				'label' => esc_html__( 'Services', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'serv_title_color',
			[
				'label' => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .svs-info > h3' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'serv_title_typography',
				'label' => esc_html__( 'Title Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .svs-info > h3',
			]
		);

		$this->add_control(
			'serv_desc_color',
			[
				'label' => esc_html__( 'Description Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .svs-info > p' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'serv_desc_typography',
				'label' => esc_html__( 'Description Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .svs-info > p',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'title', 'basic' );
		$this->add_inline_editing_attributes( 'description', 'advanced' );

		?>

		<section class="block2 pb-0">
			<div class="custom-container">
				<?php if ( $settings['title'] || $settings['description'] ) : ?>
				<div class="section-title style2 align-items-center">
					<?php if ( $settings['title'] ) : ?>
					<h3 class="sub-title">
						<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
							<?php echo wp_kses_post( $settings['title'] ); ?>
						</span>
					</h3>
					<?php endif; ?>
					<?php if ( $settings['description'] ) : ?>
					<div class="description">
						<div <?php echo $this->get_render_attribute_string( 'description' ); ?>>
							<?php echo wp_kses_post( $settings['description'] ); ?>
						</div>
					</div>
					<?php endif; ?>
					<div class="clearfix"></div>
				</div><!--section-title end-->
				<?php endif; ?>

				<div class="services-section">
					<div class="row">
						<div class="col-lg-7">
							<div class="post-section">
								<?php if ( $settings['team_items'] ) : ?>
								<div class="row">
									<?php foreach ( $settings['team_items'] as $index => $item ) :
								    	$item_name = $this->get_repeater_setting_key( 'name', 'team_items', $index );
								    	$this->add_inline_editing_attributes( $item_name, 'basic' );

								    	$item_role = $this->get_repeater_setting_key( 'role', 'team_items', $index );
								    	$this->add_inline_editing_attributes( $item_role, 'basic' );

								    	$item_description = $this->get_repeater_setting_key( 'description', 'team_items', $index );
								    	$this->add_inline_editing_attributes( $item_description, 'advanced' );
								    ?>
									<div class="col-lg-6 col-md-6 col-sm-6">
										<div class="post-col">
											<?php if ( $item['image'] ) : $image = wp_get_attachment_image_url( $item['image']['id'], 'minterio_900x900' ); ?>
											<div class="post-thumbnail">
												<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>" />
											</div><!--post-thumbnail end-->
											<?php endif; ?>
											<div class="post-info">
												<?php if ( $item['role'] ) : ?>
												<span>
													<span <?php echo $this->get_render_attribute_string( $item_role ); ?>>
														<?php echo wp_kses_post( $item['role'] ); ?>
													</span>
												</span>
												<?php endif; ?>
												<?php if ( $item['name'] ) : ?>
												<h2>
													<span <?php echo $this->get_render_attribute_string( $item_name ); ?>>
														<?php echo wp_kses_post( $item['name'] ); ?>
													</span>
												</h2>
												<?php endif; ?>
												<?php if ( $item['description'] ) : ?>
												<div class="description">
													<div <?php echo $this->get_render_attribute_string( $item_description ); ?>>
														<?php echo wp_kses_post( $item['description'] ); ?>
													</div>
												</div>
												<?php endif; ?>
											</div><!--post-info end-->
										</div><!--post-col end-->
									</div>
									<?php endforeach; ?>
								</div>
								<?php endif; ?>
							</div>
						</div>
						<div class="col-lg-5">
							<div class="svs-list">
								<?php if ( $settings['serv_items'] ) : ?>
								<ul>
									<?php foreach ( $settings['serv_items'] as $index => $item ) :
								    	$item_title = $this->get_repeater_setting_key( 'title', 'serv_items', $index );
								    	$this->add_inline_editing_attributes( $item_title, 'basic' );

								    	$item_description = $this->get_repeater_setting_key( 'description', 'serv_items', $index );
								    	$this->add_inline_editing_attributes( $item_description, 'advanced' );
								    ?>
									<li>
										<div class="svs-info">
											<?php if ( $item['image'] ) : $image = wp_get_attachment_image_url( $item['image']['id'], 'minterio_900xAuto' ); ?>
											<img src="<?php echo esc_url( $image ); ?>" alt="" />
											<?php endif; ?>
											<?php if ( $item['title'] ) : ?>
											<h3>
												<span <?php echo $this->get_render_attribute_string( $item_title ); ?>>
													<?php echo wp_kses_post( $item['title'] ); ?>
												</span>
											</h3>
											<?php endif; ?>
											<?php if ( $item['description'] ) : ?>
											<p>
												<span <?php echo $this->get_render_attribute_string( $item_description ); ?>>
													<?php echo wp_kses_post( $item['description'] ); ?>
												</span>
											</p>
											<?php endif; ?>
										</div>
										<div class="clearfix"></div>
									</li>
									<?php endforeach; ?>
								</ul>
								<?php endif; ?>
							</div><!--svs-list end-->
						</div>
					</div>
				</div><!--services-section end-->
			</div>
		</section>

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() { ?>
		<#
		view.addInlineEditingAttributes( 'title', 'basic' );
		view.addInlineEditingAttributes( 'description', 'advanced' );
		#>

		<section class="block2 pb-0">
			<div class="custom-container">
				<# if ( settings.title || settings.description ) { #>
				<div class="section-title style2 align-items-center">
					<# if ( settings.title ) { #>
					<h3 class="sub-title">
						<span {{{ view.getRenderAttributeString( 'title' ) }}}>
            				{{{ settings.title }}}
            			</span>
					</h3>
					<# } #>
					<# if ( settings.description ) { #>
					<div class="description">
						<div {{{ view.getRenderAttributeString( 'description' ) }}}>
            				{{{ settings.description }}}
            			</div>
					</div>
					<# } #>
					<div class="clearfix"></div>
				</div><!--section-title end-->
				<# } #>

				<div class="services-section">
					<div class="row">
						<div class="col-lg-7">
							<div class="post-section">
								<# if ( settings.team_items ) { #>
								<div class="row">
								    <# _.each( settings.team_items, function( item, index ) {
										var item_role = view.getRepeaterSettingKey( 'role', 'team_items', index );
									    view.addInlineEditingAttributes( item_role, 'basic' );

									    var item_name = view.getRepeaterSettingKey( 'title', 'team_items', index );
									    view.addInlineEditingAttributes( item_name, 'basic' );

									    var item_description = view.getRepeaterSettingKey( 'description', 'team_items', index );
									    view.addInlineEditingAttributes( item_description, 'advanced' );
									#>
									<div class="col-lg-6 col-md-6 col-sm-6">
										<div class="post-col">
											<# if ( item.image ) { #>
											<div class="post-thumbnail">
												<img src="{{{ item.image.url }}}" alt="{{{ item.name }}}" />
											</div><!--post-thumbnail end-->
											<# } #>
											<div class="post-info">
												<# if ( item.role ) { #>
												<span>
													<span {{{ view.getRenderAttributeString( item_role ) }}}>
														{{{ item.role }}}
													</span>
												</span>
												<# } #>
												<# if ( item.name ) { #>
												<h2>
													<span {{{ view.getRenderAttributeString( item_name ) }}}>
														{{{ item.name }}}
													</span>
												</h2>
												<# } #>
												<# if ( item.description ) { #>
												<div class="description">
													<div {{{ view.getRenderAttributeString( item_description ) }}}>
														{{{ item.description }}}
													</div>
												</div>
												<# } #>
											</div><!--post-info end-->
										</div><!--post-col end-->
									</div>
									<# }); #>
								</div>
								<# } #>
							</div>
						</div>
						<div class="col-lg-5">
							<div class="svs-list">
								<# if ( settings.serv_items ) { #>
								<ul>
								    <# _.each( settings.serv_items, function( item, index ) {
									    var item_title = view.getRepeaterSettingKey( 'title', 'serv_items', index );
									    view.addInlineEditingAttributes( item_title, 'basic' );

									    var item_description = view.getRepeaterSettingKey( 'description', 'serv_items', index );
									    view.addInlineEditingAttributes( item_description, 'advanced' );
									#>
									<li>
										<div class="svs-info">
											<# if ( item.image ) { #>
											<img src="{{{ item.image.url }}}" alt="" />
											<# } #>
											<# if ( item.title ) { #>
											<h3>
												<span {{{ view.getRenderAttributeString( item_title ) }}}>
													{{{ item.title }}}
												</span>
											</h3>
											<# } #>
											<# if ( item.description ) { #>
											<p>
												<span {{{ view.getRenderAttributeString( item_description ) }}}>
													{{{ item.description }}}
												</span>
											</p>
											<# } #>
										</div>
										<div class="clearfix"></div>
									</li>
									<# }); #>
								</ul>
								<# } #>
							</div><!--svs-list end-->
						</div>
					</div>
				</div><!--services-section end-->
			</div>
		</section>

	<?php }
}

Plugin::instance()->widgets_manager->register( new Minterio_Services_Widget() );
