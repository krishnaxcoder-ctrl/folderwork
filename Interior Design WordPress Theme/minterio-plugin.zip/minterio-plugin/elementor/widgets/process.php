<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio Process Widget.
 *
 * @since 1.0
 */

class Minterio_Process_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-process';
	}

	public function get_title() {
		return esc_html__( 'Process', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'heading_tab',
			[
				'label' => esc_html__( 'Heading', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'button',
			[
				'label'       => esc_html__( 'Button (Text)', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter Button Label', 'minterio-plugin' ),
				'default'     => esc_html__( 'Button', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'link',
			[
				'label' => esc_html__( 'Button (URL)', 'minterio-plugin' ),
				'label_block' => true,
				'type' => Controls_Manager::URL,
				'show_external' => true,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_tab',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'title', [
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default' => esc_html__( 'Title', 'minterio-plugin' ),
			]
		);

		$repeater->add_control(
			'num', [
				'label'       => esc_html__( 'Num', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter num', 'minterio-plugin' ),
				'default' => esc_html__( '01.', 'minterio-plugin' ),
			]
		);

		$repeater->add_control(
			'description', [
				'label'       => esc_html__( 'Description', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter description', 'minterio-plugin' ),
				'default' => esc_html__( 'Description', 'minterio-plugin' ),
			]
		);

		$this->add_control(
			'items',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'heading_styling',
			[
				'label' => esc_html__( 'Heading', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .sub-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Title Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .sub-title',
			]
		);

		$this->add_control(
			'button_color',
			[
				'label' => esc_html__( 'Button Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .section-title .lnk-default2' => 'color: {{VALUE}};',
					'{{WRAPPER}} .section-title .lnk-default2:before' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_typography',
				'label' => esc_html__( 'Button Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .section-title .lnk-default2',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_styling',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'item_title_color',
			[
				'label' => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .proz-minterio > h3' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_title_typography',
				'label' => esc_html__( 'Title Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .proz-minterio > h3',
			]
		);

		$this->add_control(
			'item_num_color',
			[
				'label' => esc_html__( 'Num Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .proz-minterio .p-num' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_num_typography',
				'label' => esc_html__( 'Num Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .proz-minterio .p-num',
			]
		);

		$this->add_control(
			'item_desc_color',
			[
				'label' => esc_html__( 'Description Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .proz-minterio > p' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_desc_typography',
				'label' => esc_html__( 'Description Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .proz-minterio > p',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'title', 'basic' );
		$this->add_inline_editing_attributes( 'button', 'basic' );

		?>

		<section class="block">
			<div class="container">
				<?php if ( $settings['title'] || $settings['button'] ) : ?>
				<div class="section-title align-items-center">
					<?php if ( $settings['title'] ) : ?>
					<h3 class="sub-title">
						<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
							<?php echo wp_kses_post( $settings['title'] ); ?>
						</span>
					</h3>
					<?php endif; ?>
					<?php if ( $settings['button'] ) : ?>
					<a<?php if ( $settings['link'] ) : ?><?php if ( $settings['link']['is_external'] ) : ?> target="_blank"<?php endif; ?><?php if ( $settings['link']['nofollow'] ) : ?> rel="nofollow"<?php endif; ?> href="<?php echo esc_url( $settings['link']['url'] ); ?>"<?php endif; ?> class="lnk-default2">
						<span <?php echo $this->get_render_attribute_string( 'button' ); ?>>
							<?php echo wp_kses_post( $settings['button'] ); ?>
						</span>
						<i class="la la-arrow-right"></i>
					</a>
					<?php endif; ?>
				</div><!--section-title end-->
				<?php endif; ?>

				<div class="process-section">
					<?php if ( $settings['items'] ) : ?>
					<ul>
						<?php foreach ( $settings['items'] as $index => $item ) :
							$item_title = $this->get_repeater_setting_key( 'title', 'items', $index );
					    	$this->add_inline_editing_attributes( $item_title, 'basic' );

					    	$item_num = $this->get_repeater_setting_key( 'num', 'items', $index );
					    	$this->add_inline_editing_attributes( $item_num, 'basic' );

					    	$item_desc = $this->get_repeater_setting_key( 'description', 'items', $index );
					    	$this->add_inline_editing_attributes( $item_desc, 'basic' );
						?>
						<li>
							<div class="proz-minterio">
								<?php if ( $item['title'] ) : ?>
								<h3>
									<span <?php echo $this->get_render_attribute_string( $item_title ); ?>>
										<?php echo wp_kses_post( $item['title'] ); ?>
									</span>
								</h3>
								<?php endif; ?>
								<?php if ( $item['description'] ) : ?>
								<p>
									<span <?php echo $this->get_render_attribute_string( $item_desc ); ?>>
										<?php echo wp_kses_post( $item['description'] ); ?>
									</span>
								</p>
								<?php endif; ?>
								<?php if ( $item['num'] ) : ?>
								<h2 class="p-num">
									<span <?php echo $this->get_render_attribute_string( $item_num ); ?>>
										<?php echo wp_kses_post( $item['num'] ); ?>
									</span>
								</h2>
								<?php endif; ?>
							</div><!--proz-minterio end-->
						</li>
						<?php endforeach; ?>
					</ul>
					<?php endif; ?>
					<div class="clearfix"></div>
				</div><!--process-section end-->
			</div>
		</section>

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() { ?>

		<#
		view.addInlineEditingAttributes( 'title', 'basic' );
		view.addInlineEditingAttributes( 'button', 'basic' );
		#>

		<section class="block">
			<div class="container">
				<# if ( settings.title || settings.button ) { #>
				<div class="section-title align-items-center">
					<# if ( settings.title ) { #>
					<h3 class="sub-title">
						<span {{{ view.getRenderAttributeString( 'title' ) }}}>
	        				{{{ settings.title }}}
	        			</span>
					</h3>
					<# } #>
					<# if ( settings.button ) { #>
					<a<# if ( settings.link ) { #><# if ( settings.link.is_external ) { #> target="_blank"<# } #><# if ( settings.link.nofollow ) { #> rel="nofollow"<# } #> href="{{{ settings.link.url }}}"<# } #> class="lnk-default2">
						<span {{{ view.getRenderAttributeString( 'button' ) }}}>{{{ settings.button }}}</span>
						<i class="la la-arrow-right"></i>
					</a>
					<# } #>
				</div><!--section-title end-->
				<# } #>

				<div class="process-section">
					<# if ( settings.items ) { #>
					<ul>
						<# _.each( settings.items, function( item, index ) {
							var item_title = view.getRepeaterSettingKey( 'title', 'items', index );
						    view.addInlineEditingAttributes( item_title, 'basic' );

						    var item_num = view.getRepeaterSettingKey( 'num', 'items', index );
						    view.addInlineEditingAttributes( item_num, 'basic' );

						    var item_desc = view.getRepeaterSettingKey( 'description', 'items', index );
						    view.addInlineEditingAttributes( item_desc, 'basic' );
						#>
						<li>
							<div class="proz-minterio">
								<# if ( item.title ) { #>
								<h3>
									<span {{{ view.getRenderAttributeString( item_title ) }}}>
										{{{ item.title }}}
									</span>
								</h3>
								<# } #>
								<# if ( item.description ) { #>
								<p>
									<span {{{ view.getRenderAttributeString( item_desc ) }}}>
										{{{ item.description }}}
									</span>
								</p>
								<# } #>
								<# if ( item.num ) { #>
								<h2 class="p-num">
									<span {{{ view.getRenderAttributeString( item_num ) }}}>
										{{{ item.num }}}
									</span>
								</h2>
								<# } #>
							</div><!--proz-minterio end-->
						</li>
						<# }); #>
					</ul>
					<# } #>
					<div class="clearfix"></div>
				</div><!--process-section end-->
			</div>
		</section>

	<?php }
}

Plugin::instance()->widgets_manager->register( new Minterio_Process_Widget() );
