<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio Breadcrumbs Widget.
 *
 * @since 1.0
 */
class Minterio_Breadcrumbs_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-breadcrumbs';
	}

	public function get_title() {
		return esc_html__( 'Breadcrumbs', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'content_styling',
			[
				'label'     => esc_html__( 'Breadcrumbs Styling', 'minterio-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'item_link_color',
			[
				'label'     => esc_html__( 'Link Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .breadcrumb li a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'item_link_active_color',
			[
				'label'     => esc_html__( 'Active Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .breadcrumb li span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'item_link_typography',
				'label'     => esc_html__( 'Link Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .breadcrumb li',
			]
		);

		$this->end_controls_section();
	}


	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$page_id = get_the_ID();

		?>

		<section class="pager-section mb-0 no-bg style2">
			<div class="container">
				<div class="pager-info">
					<?php minterio_breadcrumbs( $page_id ); ?>
				</div>
				<div class="clearfix"></div>
			</div>
		</section><!--pager-section end-->

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() { ?>

	<section class="pager-section mb-0 no-bg style2">
		<div class="container">
			<div class="pager-info">
				[breadcrumbs]
			</div>
			<div class="clearfix"></div>
		</div>
	</section><!--pager-section end-->

	<?php }
}

Plugin::instance()->widgets_manager->register( new Minterio_Breadcrumbs_Widget() );
