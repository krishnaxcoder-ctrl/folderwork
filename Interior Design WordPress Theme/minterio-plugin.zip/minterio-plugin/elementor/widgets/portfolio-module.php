<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio Portfolio Module Widget.
 *
 * @since 1.0
 */
class Minterio_Portfolio_Module_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-portfolio-module';
	}

	public function get_title() {
		return esc_html__( 'Portfolio (Module)', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'content_tab',
			[
				'label' => esc_html__( 'Content', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default'     => esc_html__( 'Title', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'minterio-plugin' ),
				'type'        => Controls_Manager::WYSIWYG,
				'placeholder' => esc_html__( 'Enter your description', 'minterio-plugin' ),
				'default'     => esc_html__( 'Description', 'minterio-plugin' ),
			]
		);

		$this->add_control(
			'button',
			[
				'label'       => esc_html__( 'Button (Text)', 'minterio-plugin' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter Button Label', 'minterio-plugin' ),
				'default'     => esc_html__( 'Button', 'minterio-plugin' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'link',
			[
				'label' => esc_html__( 'Button (URL)', 'minterio-plugin' ),
				'label_block' => true,
				'type' => Controls_Manager::URL,
				'show_external' => true,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'bgimages', [
				'label' => esc_html__( 'Background Image', 'minterio-plugin' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri() . '/assets/images/main-banner-bg.jpg',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_tab',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'source',
			[
				'label'       => esc_html__( 'Source', 'minterio-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'all',
				'options' => [
					'all'  => __( 'All', 'minterio-plugin' ),
					'categories' => __( 'Categories', 'minterio-plugin' ),
				],
			]
		);

		$this->add_control(
			'source_categories',
			[
				'label'       => esc_html__( 'Source', 'minterio-plugin' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple' => true,
				'options' => $this->get_portfolio_categories(),
				'condition' => [
		            'source' => 'categories'
		        ],
			]
		);

		$this->add_control(
			'limit',
			[
				'label'       => esc_html__( 'Number of Items', 'minterio-plugin' ),
				'type'        => Controls_Manager::NUMBER,
				'placeholder' => 8,
				'default'     => 8,
			]
		);

		$this->add_control(
			'sort',
			[
				'label'       => esc_html__( 'Sorting By', 'minterio-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'menu_order',
				'options' => [
					'date'  => __( 'Date', 'minterio-plugin' ),
					'title' => __( 'Title', 'minterio-plugin' ),
					'rand' => __( 'Random', 'minterio-plugin' ),
					'menu_order' => __( 'Order', 'minterio-plugin' ),
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label'       => esc_html__( 'Order', 'minterio-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'asc',
				'options' => [
					'asc'  => __( 'ASC', 'minterio-plugin' ),
					'desc' => __( 'DESC', 'minterio-plugin' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'settings_tab',
			[
				'label' => esc_html__( 'Settings', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_title',
			[
				'label'       => esc_html__( 'Show Title?', 'minterio-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'yes',
				'options' => [
					'no'  => __( 'No', 'minterio-plugin' ),
					'yes' => __( 'Yes', 'minterio-plugin' ),
				],
			]
		);

		$this->add_control(
			'show_subtitle',
			[
				'label'       => esc_html__( 'Show Subtitle?', 'minterio-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'yes',
				'options' => [
					'no'  => __( 'No', 'minterio-plugin' ),
					'yes' => __( 'Yes', 'minterio-plugin' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_styling',
			[
				'label'     => esc_html__( 'Content Styling', 'minterio-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .project-text .sub-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'label'     => esc_html__( 'Title Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .project-text .sub-title',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Description Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .project-text > .description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'label'     => esc_html__( 'Description Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .project-text > .description',
			]
		);

		$this->add_control(
			'button_color',
			[
				'label'     => esc_html__( 'Button Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .project-text .lnk-default2' => 'color: {{VALUE}};',
					'{{WRAPPER}} .project-text .lnk-default2:before' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'button_typography',
				'label'     => esc_html__( 'Button Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .project-text .lnk-default2',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'items_styling',
			[
				'label'     => esc_html__( 'Items', 'minterio-plugin' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'item_title_color',
			[
				'label'     => esc_html__( 'Title Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .project-info > h3 a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'item_title_typography',
				'label'     => esc_html__( 'Title Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .project-info > h3',
			]
		);

		$this->add_control(
			'item_subtitle_color',
			[
				'label'     => esc_html__( 'Subtitle Color', 'minterio-plugin' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .project-info > span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'item_subtitle_typography',
				'label'     => esc_html__( 'Subtitle Typography', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .project-info > span',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render Categories List.
	 *
	 * @since 1.0
	 */
	protected function get_portfolio_categories() {
		$categories = [];

		$args = array(
			'type'			=> 'post',
			'child_of'		=> 0,
			'parent'		=> '',
			'orderby'		=> 'name',
			'order'			=> 'DESC',
			'hide_empty'	=> 1,
			'hierarchical'	=> 1,
			'taxonomy'		=> 'portfolio_categories',
			'pad_counts'	=> false
		);

		$portfolio_categories = get_categories( $args );

		foreach ( $portfolio_categories as $category ) {
			$categories[$category->term_id] = $category->name;
		}

		return $categories;
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'title', 'basic' );

		$paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
		$page_id = get_the_ID();

		if ( $settings['source'] == 'all' ) {
			$cat_ids = '';
		} else {
			$cat_ids = $settings['source_categories'];
		}

		$args = array(
			'post_type'			=> 'portfolio',
			'post_status'		=> 'publish',
			'orderby'			=> $settings['sort'],
			'order'				=> $settings['order'],
			'posts_per_page'	=> $settings['limit'],
			'paged' 			=> $paged
		);

		if( $settings['source'] == 'categories' ) {
			$tax_array = array(
				array(
					'taxonomy' => 'portfolio_categories',
					'field'    => 'id',
					'terms'    => $cat_ids
				)
			);

			$args += array('tax_query' => $tax_array);
		}

		$q = new \WP_Query( $args );

		$temp = 'portfolio-latest';

		$item_classes = '';

		if ( $settings['show_title'] == 'no' ) :
			$item_classes .= ' hide_title';
		endif;
		if ( $settings['show_subtitle'] == 'no' ) :
			$item_classes .= ' hide_subtitle';
		endif;
		if ( $settings['show_title'] == 'no' && $settings['show_subtitle'] == 'no' ) :
			$item_classes .= ' hide_description';
		endif;

		?>

		<section class="block2">
			<div class="fixed-bg" <?php if ( $settings['bgimages'] ) : ?>style="background-image: url(<?php echo esc_url( $settings['bgimages']['url'] ); ?>);"<?php endif; ?>></div>
			<div class="container">
				<div class="latest-projects-section">
					<div class="row">
						<div class="col-lg-5">
							<div class="project-text">
								<?php if ( $settings['title'] ) : ?>
								<h3 class="sub-title">
									<span <?php echo $this->get_render_attribute_string( 'title' ); ?>>
										<?php echo wp_kses_post( $settings['title'] ); ?>
									</span>
								</h3>
								<?php endif; ?>
								<?php if ( $settings['description'] ) : ?>
								<div class="description">
									<div <?php echo $this->get_render_attribute_string( 'description' ); ?>>
										<?php echo wp_kses_post( $settings['description'] ); ?>
									</div>
								</div>
								<?php endif; ?>
								<?php if ( $settings['button'] ) : ?>
								<a<?php if ( $settings['link'] ) : ?><?php if ( $settings['link']['is_external'] ) : ?> target="_blank"<?php endif; ?><?php if ( $settings['link']['nofollow'] ) : ?> rel="nofollow"<?php endif; ?> href="<?php echo esc_url( $settings['link']['url'] ); ?>"<?php endif; ?> class="lnk-default2">
									<span <?php echo $this->get_render_attribute_string( 'button' ); ?>>
										<?php echo esc_html( $settings['button'] ); ?>
									</span>
									<i class="la la-arrow-right"></i>
								</a>
								<?php endif; ?>
							</div><!--project-text end-->
						</div>
						<div class="col-lg-7">
							<?php if ( $q->have_posts() ) : ?>
							<div class="project-carousel <?php echo esc_html( $item_classes ); ?>">
								<?php while ( $q->have_posts() ) : $q->the_post();
									get_template_part( 'template-parts/content', $temp );
								endwhile; ?>
							</div><!--project-carousel end-->
							<?php endif; ?>
						</div>
					</div>
				</div><!--latest-projects-section end-->
			</div>
		</section>

		<?php
	}
}

Plugin::instance()->widgets_manager->register( new Minterio_Portfolio_Module_Widget() );
