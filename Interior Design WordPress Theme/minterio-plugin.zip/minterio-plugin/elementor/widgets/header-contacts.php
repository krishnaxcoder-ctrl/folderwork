<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio Header Contacts Widget.
 *
 * @since 1.0
 */
class Minterio_Header_Contacts_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-header-contacts';
	}

	public function get_title() {
		return esc_html__( 'Header Contacts', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'content_tab',
			[
				'label' => esc_html__( 'Content', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'tel',
			[
				'label'       => esc_html__( 'Tel (text)', 'minterio-plugin' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( '+123456789', 'minterio-plugin' ),
				'default'	=> '',
			]
		);

		$this->add_control(
			'button_show',
			[
				'label' => esc_html__( 'Show Button', 'minterio-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'minterio-plugin' ),
				'label_off' => __( 'Hide', 'minterio-plugin' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);

		$this->add_control(
			'button',
			[
				'label'       => esc_html__( 'Button (label)', 'minterio-plugin' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Button', 'minterio-plugin' ),
				'default'	=> esc_html__( 'Button', 'minterio-plugin' ),
				'condition' => [
		            'button_show' => 'yes',
		        ],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'link',
			[
				'label'       => esc_html__( 'Button (link)', 'minterio-plugin' ),
				'type' => Controls_Manager::URL,
				'show_external' => true,
				'condition' => [
		            'button_show' => 'yes',
		        ],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label' => __( 'Alignment', 'minterio-plugin' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'minterio-plugin' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'minterio-plugin' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'minterio-plugin' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				],
				'default'	=> 'right',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_styling',
			[
				'label' => esc_html__( 'Styles', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'tel_color',
			[
				'label' => esc_html__( 'Tel Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .contact-head-info > h4' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'tel_typography',
				'label' => esc_html__( 'Tel Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .contact-head-info > h4',
			]
		);

		$this->add_control(
			'button_color',
			[
				'label' => esc_html__( 'Button Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .contact-head-info > a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_typography',
				'label' => esc_html__( 'Button Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .contact-head-info > a',
			]
		);

		$this->end_controls_section();

	}


	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'tel', 'none' );
		$this->add_inline_editing_attributes( 'button', 'none' );

		?>

		<div class="contact-head-info">
			<?php if ( $settings['tel'] ) : ?>
			<h4>
				<span <?php echo $this->get_render_attribute_string( 'tel' ); ?>>
	          		<?php echo wp_kses_post( $settings['tel'] ); ?>
	          	</span>
			</h4>
			<?php endif; ?>
			<?php if ( $settings['button_show'] == 'yes' && $settings['button'] ) : ?>
			<a<?php if ( $settings['link'] ) : if ( $settings['link']['is_external'] ) : ?> target="_blank"<?php endif; ?><?php if ( $settings['link']['nofollow'] ) : ?> rel="nofollow"<?php endif; ?> href="<?php echo esc_url( $settings['link']['url'] ); ?>"<?php endif; ?>>
				<span <?php echo $this->get_render_attribute_string( 'button' ); ?>>
	          		<?php echo wp_kses_post( $settings['button'] ); ?>
	          	</span>
			</a>
			<?php endif; ?>
		</div><!--contact-head-info end-->

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() {
		?>
		<#
		view.addInlineEditingAttributes( 'tel', 'none' );
		view.addInlineEditingAttributes( 'button', 'none' );
		#>

		<div class="contact-head-info">
			<# if ( settings.tel ) { #>
			<h4>
				<span {{{ view.getRenderAttributeString( 'tel' ) }}}>
	          		{{{ settings.tel }}}
	          	</span>
			</h4>
			<# } #>
			<# if ( settings.button_show == 'yes' && settings.button ) { #>
			<a<# if ( settings.link ) { if ( settings.link.is_external ) { #> target="_blank"<# } #><# if ( settings.link.nofollow ) { #> rel="nofollow"<# } #> href="{{{ settings.link.url }}}"<# } #>>
				<span {{{ view.getRenderAttributeString( 'button' ) }}}>
	          		{{{ settings.button }}}
	          	</span>
			</a>
			<# } #>
		</div><!--contact-head-info end-->

		<?php
	}
}

Plugin::instance()->widgets_manager->register( new Minterio_Header_Contacts_Widget() );
