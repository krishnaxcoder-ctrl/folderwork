<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Minterio Footer Social Links Widget.
 *
 * @since 1.0
 */
class Minterio_Footer_Social_Links_Widget extends Widget_Base {

	public function get_name() {
		return 'minterio-footer-social-links';
	}

	public function get_title() {
		return esc_html__( 'Footer Social Links', 'minterio-plugin' );
	}

	public function get_icon() {
		return 'eicon-parallax';
	}

	public function get_categories() {
		return [ 'minterio-category' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @since 1.0
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'content_tab',
			[
				'label' => esc_html__( 'Content', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'type',
			[
				'label'       => esc_html__( 'Display', 'minterio-plugin' ),
				'type'        => Controls_Manager::SELECT,
				'default' => 'text',
				'options' => [
					'text'  => __( 'Text', 'minterio-plugin' ),
					'icons' => __( 'Icons', 'minterio-plugin' ),
				],
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'icon', [
				'label'       => esc_html__( 'Icon', 'myour-plugin' ),
				'type'        => Controls_Manager::ICONS,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'name', [
				'label'       => esc_html__( 'Name', 'minterio-plugin' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default' => esc_html__( 'Enter title', 'minterio-plugin' ),
			]
		);

		$repeater->add_control(
			'title', [
				'label'       => esc_html__( 'Title', 'minterio-plugin' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter title', 'minterio-plugin' ),
				'default' => esc_html__( 'Enter title', 'minterio-plugin' ),
			]
		);

		$repeater->add_control(
			'link', [
				'label' => esc_html__( 'URL', 'minterio-plugin' ),
				'label_block' => true,
				'type' => Controls_Manager::URL,
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'items',
			[
				'label' => esc_html__( 'Items', 'minterio-plugin' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_styling',
			[
				'label' => esc_html__( 'Footer Social Links', 'minterio-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'link_color',
			[
				'label' => esc_html__( 'Link Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .social-links a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .social-links a svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'link_bgcolor',
			[
				'label' => esc_html__( 'Link BG Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .social-links a' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'link_active_color',
			[
				'label' => esc_html__( 'Link Hover Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .social-links a:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .social-links a:hover svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'link_active_bgcolor',
			[
				'label' => esc_html__( 'Link Hover BG Color', 'minterio-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .social-links a:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'link_typography',
				'label' => esc_html__( 'Link Typography:', 'minterio-plugin' ),
				'selector' => '{{WRAPPER}} .social-links a',
			]
		);

		$this->end_controls_section();

	}


	/**
	 * Render widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<?php if ( $settings['items'] ) : ?>
		<ul class="social-links">
			<?php foreach ( $settings['items'] as $index => $item ) :
		    	$item_name = $this->get_repeater_setting_key( 'name', 'items', $index );
		    	$this->add_inline_editing_attributes( $item_name, 'basic' );
		    ?>
			<li>
				<a<?php if ( $item['link'] ) : ?><?php if ( $item['link']['is_external'] ) : ?> target="_blank"<?php endif; ?><?php if ( $item['link']['nofollow'] ) : ?> rel="nofollow"<?php endif; ?> href="<?php echo esc_url( $item['link']['url'] ); ?>"<?php endif; ?>>
					<?php if ( $settings['type'] == 'icons' ) : ?>
						<?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
					<?php else : ?>
						<span <?php echo $this->get_render_attribute_string( $item_name ); ?>>
							<?php echo wp_kses_post( $item['name'] ); ?>
						</span>
					<?php endif; ?>
				</a>
			</li>
			<?php endforeach; ?>
		</ul><!--social-links end-->
		<?php endif; ?>

		<?php
	}

	/**
	 * Render widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() {
		?>

		<# if ( settings.items ) { #>
		<ul class="social-links">
			<# _.each( settings.items, function( item, index ) {
				var item_name = view.getRepeaterSettingKey( 'name', 'items', index );
			    view.addInlineEditingAttributes( item_name, 'basic' );

				var iconHTML = elementor.helpers.renderIcon( view, item.icon, { 'aria-hidden': true }, 'i' , 'object' );
			#>
			<li>
				<a<# if ( item.link ) { #><# if ( item.link.is_external ) { #> target="_blank"<# } #><# if ( item.link.nofollow ) { #> rel="nofollow"<# } #> href="{{{ item.link.url }}}"<# } #>>
					<# if ( settings.type == 'icons' ) { #>
						{{{ iconHTML.value }}}
					<# } else { #>
						<span {{{ view.getRenderAttributeString( item_name ) }}}>
							{{{ item.name }}}
						</span>
					<# } #>
				</a>
			</li>
			<# }); #>
		</ul><!--social-links end-->
		<# } #>

		<?php
	}
}

Plugin::instance()->widgets_manager->register( new Minterio_Footer_Social_Links_Widget() );
