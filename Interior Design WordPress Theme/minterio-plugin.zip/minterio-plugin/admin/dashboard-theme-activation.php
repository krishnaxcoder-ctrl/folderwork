<?php

require_once "includes/MinterioBase.php";

if ( ! class_exists( 'MinterioThemeActivation' ) ) {
class MinterioThemeActivation {
  public $plugin_file= __FILE__;
  public $responseObj;
  public $licenseMessage;
  public $showMessage = false;
  public $slug = 'minterio';

    function __construct() {
        // Pre-activated: Always set theme as activated
        add_filter( 'minterio/is_theme_activated', '__return_true' );
        update_option( 'Minterio_lic_Status', 'active' );

        // Create a mock response object for the activated form
        $this->responseObj = new stdClass();
        $this->responseObj->is_valid = true;
        $this->responseObj->license_title = 'Developer License';
        $this->responseObj->expire_date = 'No Expiry';
        $this->responseObj->support_end = 'Unlimited';
        $this->responseObj->license_key = 'DEVELOPER-LICENSE-PREACTIVATED';
        $this->responseObj->support_renew_link = '';

        add_action( 'minterio_theme_dashboard_activation_form', [ $this, 'activated_form_content' ] );
    }
    function action_activate_license(){
        check_admin_referer( 'el-license' );
        $licenseKey = ! empty( $_POST['el_license_key'] ) ? $_POST['el_license_key']: '';
        $licenseEmail = ! empty( $_POST['el_license_email'] ) ? $_POST['el_license_email']: '';
        update_option( 'Minterio_lic_Key', $licenseKey ) || add_option( 'Minterio_lic_Key', $licenseKey);
        update_option( 'Minterio_lic_email', $licenseEmail ) || add_option( 'Minterio_lic_email', $licenseEmail );

        update_option( '_site_transient_update_themes', '' );
        update_option( '_site_transient_update_plugins', '' );
        wp_safe_redirect( admin_url( 'admin.php?page=' . $this->slug . '-theme-activation' ) );
    }
    function action_deactivate_license() {
        check_admin_referer( 'el-license' );
        $message = '';
        if ( MinterioBase::RemoveLicenseKey( __FILE__,$message ) ) {
            update_option( 'Minterio_lic_Key', '' ) || add_option( 'Minterio_lic_Key', '' );
            update_option( 'Minterio_lic_Status', '') || add_option( 'Minterio_lic_Status', '');

            update_option( '_site_transient_update_themes', '' );
            update_option( '_site_transient_update_plugins', '' );
        }
        wp_safe_redirect( admin_url( 'admin.php?page='.$this->slug . '-theme-activation' ) );
    }
    function activated_form_content(){
        ?>
        <div class="minterio-dashboard-activation">
          <h2><?php echo esc_html__( 'Minterio Theme is activated!', 'minterio-plugin' ); ?></h2>
          <p><?php echo esc_html__( 'Your theme is pre-activated for development.', 'minterio-plugin' ); ?></p>

            <div class="minterio-dashboard-list">
              <ul>
                <li>
                   <strong><?php echo esc_html__( 'Status:', 'minterio-plugin' );?></strong>
                   <span class="el-license-valid"><?php echo esc_html__( 'Activated', 'minterio-plugin' );?></span>
                </li>
                <li>
                   <strong><?php echo esc_html__( 'License Type:', 'minterio-plugin' );?></strong>
                   <?php echo esc_html( $this->responseObj->license_title ); ?>
                </li>
                <li>
                   <strong><?php echo esc_html__( 'License Expiry:', 'minterio-plugin' );?></strong>
                   <?php echo esc_html( $this->responseObj->expire_date ); ?>
                </li>
              </ul>
           
            </div>

        </div>
    <?php
    }

    function license_form_content() {
        ?>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="Minterio_el_activate_license"/>
            <div class="minterio-dashboard-activation">
                <h2><?php echo esc_html__( 'Activate Minterio Theme and Support', $this->slug );?></h3>
                <?php
                if ( !empty( $this->showMessage ) && !empty( $this->licenseMessage ) ) {
                    ?>
                    <div class="notice notice-error is-dismissible">
                        <p><?php echo esc_html__( $this->licenseMessage, 'minterio-plugin' ); ?></p>
                    </div>
                    <?php
                }
                ?>
                <p><?php echo esc_html__( 'Enter your purchase code here, to activate your copy of Minterio theme, and get access to premium support and lifetime auto theme updates.', 'minterio-plugin' );?></p>
                <p><i><?php echo sprintf( 'Not have purchase code yet? Buy now on <a href="%s" target="_blank">Envato Market</a>', 'https://1.envato.market/AoBV0K' ); ?></i></p>
                <table>
                  <tr>
                    <th><label for="el_license_key"><?php echo esc_html__( 'Purchase Code', 'minterio-plugin' ); ?></label></th>
                    <td>
                      <input type="text" class="regular-text code" name="el_license_key" size="50" placeholder="<?php echo esc_attr__( 'xxxxxxxx-xxxxxxxx-xxxxxxxx-xxxxxxxx', 'minterio-plugin' ); ?>" required="required" />
                      <div class="description">
                        <?php echo esc_html__( 'Can\'t find the purchase code?', 'minterio-plugin' ); ?> <a target="_blank" href="https://1.envato.market/c/1790164/275988/4415?u=https://help.market.envato.com/hc/en-us/articles/202822600-Where-Is-My-Purchase-Code-"><?php echo esc_html__( 'Follow this guide', 'minterio-plugin' ); ?></a>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th><label for="el_license_email"><?php echo esc_html__( 'Email Address', 'minterio-plugin' ); ?></label></th>
                    <td>
                      <?php
                          $purchaseEmail = get_option( 'Minterio_lic_email', get_bloginfo( 'admin_email' ) );
                      ?>
                      <input type="text" class="regular-text code" name="el_license_email" size="50" value="<?php echo esc_attr( $purchaseEmail ); ?>" placeholder="<?php echo esc_attr__( 'your-email@domain.com', 'minterio-plugin' ); ?>" required="required" />
                      <div class="description"><?php echo esc_html__( 'We will send update news of this theme by this email, don\'t worry, we hate spam', 'minterio-plugin' );?></div>
                    </td>
                  </tr>
                  <tr>
                    <th></th>
                    <td>
                      <div class="buttons">
                          <?php wp_nonce_field( 'el-license' ); ?>
                          <?php submit_button( esc_attr__( 'Submit', 'minterio-plugin' ) ); ?>
                      </div>
                    </td>
                  </tr>
                </table>

                <div class="notice notice-info">
                    <p><?php echo esc_html__( 'Note! You are not required to separately register / activated any of the plugins which are bundled with the theme.', 'minterio-plugin' ); ?></p>
                </div>
                <div class="notice notice-info">
                    <p><?php echo sprintf( __( 'Note! You can have <strong>ONE active theme installation</strong> at a time. You can move the license to a different domain by "Deactivate License" from the active theme installation and then re-activate the theme on a different WordPress installation.', 'minterio-plugin' ) ); ?></p>
                </div>
                <p style="margin-top: 30px;"><strong><?php echo sprintf( __( 'Manage Your License', 'minterio-plugin' ) ); ?></strong></p>
                <div class="notice notice-info">
                  <p><?php echo sprintf( __( 'To manage all your activation, please, register an account and login on <a href="https://licenses.bslthemes.com/" target="_blank">Bslthemes License Manager</a> using your already registered email and purchase code.', 'minterio-plugin' ) ); ?></p>
                </div>


            </div>
        </form>
        <?php
    }
}

}

new MinterioThemeActivation();
